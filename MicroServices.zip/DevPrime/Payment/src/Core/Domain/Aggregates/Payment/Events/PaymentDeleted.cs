namespace Domain.Aggregates.Payment.Events;
public class PaymentDeleted : DomainEvent
{
    public PaymentDeleted() : base()
    {
    }
}