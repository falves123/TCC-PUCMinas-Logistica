namespace Domain.Aggregates.Payment.Events;
public class PaymentUpdated : DomainEvent
{
    public PaymentUpdated() : base()
    {
    }
}