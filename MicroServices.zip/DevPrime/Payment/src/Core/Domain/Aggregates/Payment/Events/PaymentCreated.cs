namespace Domain.Aggregates.Payment.Events;
public class PaymentCreated : DomainEvent
{
    public PaymentCreated() : base()
    {
    }
}