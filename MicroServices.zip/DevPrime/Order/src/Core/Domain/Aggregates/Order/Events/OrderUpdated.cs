namespace Domain.Aggregates.Order.Events;
public class OrderUpdated : DomainEvent
{
    public OrderUpdated() : base()
    {
    }
}