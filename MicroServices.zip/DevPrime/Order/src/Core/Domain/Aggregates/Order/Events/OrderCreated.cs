namespace Domain.Aggregates.Order.Events;
public class OrderCreated : DomainEvent
{
    public OrderCreated() : base()
    {
    }
}