namespace Domain.Aggregates.Order.Events;
public class OrderDeleted : DomainEvent
{
    public OrderDeleted() : base()
    {
    }
}