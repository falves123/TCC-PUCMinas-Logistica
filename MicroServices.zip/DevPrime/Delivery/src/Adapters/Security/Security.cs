﻿namespace DevPrime.Security
{
    public class Security
    {
    }
}
