﻿//global using Application.Interfaces.Services;
global using DevPrime.Stack.Foundation.Stream;
global using DevPrime.Stack.Stream;