﻿namespace DevPrime.Extensions;
public class Extensions : IExtensions
{
  
}