﻿global using DevPrime.Stack.Foundation;
global using DevPrime.Stack.Extensions;
global using Application.Interfaces.Adapters.Extensions;
