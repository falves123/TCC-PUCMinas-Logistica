﻿namespace DevPrime.Stack.AppCenter
{
    public class AppCenter
    {
        
    }
}
