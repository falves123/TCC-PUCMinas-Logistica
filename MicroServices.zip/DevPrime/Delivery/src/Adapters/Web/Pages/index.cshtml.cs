namespace DevPrime.Web;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
