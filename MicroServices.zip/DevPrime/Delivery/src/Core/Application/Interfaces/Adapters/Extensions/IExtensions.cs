﻿namespace Application.Interfaces.Adapters.Extensions;
public interface IExtensions
{
}