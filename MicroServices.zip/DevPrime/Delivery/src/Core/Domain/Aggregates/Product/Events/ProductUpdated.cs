namespace Domain.Aggregates.Product.Events;
public class ProductUpdated : DomainEvent
{
    public ProductUpdated() : base()
    {
    }
}