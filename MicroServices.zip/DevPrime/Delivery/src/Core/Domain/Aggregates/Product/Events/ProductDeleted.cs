namespace Domain.Aggregates.Product.Events;
public class ProductDeleted : DomainEvent
{
    public ProductDeleted() : base()
    {
    }
}