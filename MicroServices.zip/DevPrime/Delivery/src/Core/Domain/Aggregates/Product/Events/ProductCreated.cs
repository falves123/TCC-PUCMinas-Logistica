namespace Domain.Aggregates.Product.Events;
public class ProductCreated : DomainEvent
{
    public ProductCreated() : base()
    {
    }
}