global using System.Collections.Generic;
global using System;
global using System.Text;
global using System.Linq;
global using DevPrime.Stack.Foundation;
global using Domain.Aggregates.Product.Events;
global using DevPrime.Stack.Foundation.Exceptions;