﻿using System.Threading;
using System.Threading.Tasks;

using Xunit;

using Microsoft.Extensions.DependencyInjection;

using SKY.SPS.CrossCutting.Utility;
using SKY.SPS.CrossCutting.Enrichment;

namespace SKY.SPS.Enrichment.NewSubscriber.FunctionalTests.Scenarios
{
    public class NewSubscriberScenario : ScenarioBase
    {
        private readonly IEnrichmentService _service;

        public NewSubscriberScenario()
        {
            var server = CreateServer();

            _service = server.Services.GetService<IEnrichmentService>();
        }

        [Fact]
        public async Task Process_When_RequestWithFulfillmentOrder_ShouldReturn_ResponseCommand()
        {
            // Arrange
            var message = Builders.FulfillmentOrderNewSubscriberCommandFake.ToSerialize();

            // Act
            var response = await _service.Process(message, CancellationToken.None).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.Errors);
        }

        [Fact]
        public async Task Process_When_RequestWithInstalledProduct_ShouldReturn_ResponseCommand()
        {
            // Arrange
            var message = Builders.InstalledProductNewSubscriberCommandFake.ToSerialize();

            // Act
            var response = await _service.Process(message, CancellationToken.None).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.Errors);
        }
    }
}