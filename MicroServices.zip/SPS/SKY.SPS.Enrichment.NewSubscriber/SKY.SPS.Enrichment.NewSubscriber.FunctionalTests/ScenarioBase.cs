﻿using Microsoft.Extensions.Hosting;

namespace SKY.SPS.Enrichment.NewSubscriber.FunctionalTests
{
    public class ScenarioBase
    {
        protected IHost CreateServer()
        {
            return Program.CreateHost()
                .UseEnvironment("Development")
                .Build();
        }
    }
}