﻿using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;

namespace SKY.SPS.Enrichment.NewSubscriber.FunctionalTests
{
    public static class Builders
    {
        public static ProcessFulfillmentOrderNewSubscriberCommand FulfillmentOrderNewSubscriberCommandFake => 
            new ProcessFulfillmentOrderNewSubscriberCommand
            {
                Account = "1511188114",
                FulfillmentOrder = "1-53242187074",
                SourceSystem = "Enrichment.NewSubscriber.FunctionalTests",
                User = "functionalTests_user",
                Process = "Enrichment",
                Bundle = "PTV_BUNDLE_NEW_SUBSCRIBER",
                Smartcard = "000586014698"
            };

        public static ProcessInstalledProductNewSubscriberCommand InstalledProductNewSubscriberCommandFake =>
            new ProcessInstalledProductNewSubscriberCommand
            {
                Account = "1511188114",
                SourceSystem = "Enrichment.NewSubscriber.FunctionalTests",
                User = "functionalTests_user",
                Process = "Enrichment",
                Bundle = "PTV_BUNDLE_NEW_SUBSCRIBER",
                Smartcard = "000586014698"
            };
    }
}