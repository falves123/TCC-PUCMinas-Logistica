﻿using MediatR;

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

using SKY.SPS.CrossCutting.Enrichment;
using SKY.SPS.CrossCutting.Domain.Events;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Application.Services
{
    public class NewSubscriberService : EnrichmentService
    {
        public NewSubscriberService(IMediator mediator, ILogger<NewSubscriberService> logger, IOptions<ApplicationSettings> options) : base(mediator, logger, options)
        {
        }

        protected override Message CreateCommand(string message)
        {
            return NewSubscriberCommandFactoryMethod.CreateCommand(message);
        }
    }
}