﻿using System.Reflection;
using System.Diagnostics.CodeAnalysis;

using Autofac;
using MediatR;
using FluentValidation;

using SKY.SPS.CrossCutting.Notification;
using SKY.SPS.CrossCutting.Domain.Behaviors;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Validators;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.CommandHandlers;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.EventHandlers.BundleEnrichmentedEvent;
using Module = Autofac.Module;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations
{
    [ExcludeFromCodeCoverage]
    public class MediatorModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterAssemblyTypes(typeof(IMediator).GetTypeInfo().Assembly).AsImplementedInterfaces();
            builder.RegisterAssemblyTypes(typeof(ProcessInstalledProductNewSubscriberHandler).GetTypeInfo().Assembly).AsClosedTypesOf(typeof(IRequestHandler<,>));
            builder.RegisterAssemblyTypes(typeof(NotificationHandler).GetTypeInfo().Assembly).AsClosedTypesOf(typeof(INotificationHandler<>));
            builder.RegisterAssemblyTypes(typeof(SendBundleToSendEMMGHandler).GetTypeInfo().Assembly).AsClosedTypesOf(typeof(INotificationHandler<>));
            builder.RegisterAssemblyTypes(typeof(ProcessInstalledProductNewSubscriberValidator).GetTypeInfo().Assembly).Where(t => t.IsClosedTypeOf(typeof(IValidator<>))).AsImplementedInterfaces();

            builder.Register<ServiceFactory>(context =>
            {
                var componentContext = context.Resolve<IComponentContext>();
                return t => componentContext.TryResolve(t, out var o) ? o : null;
            });

            builder.RegisterGeneric(typeof(ValidatorBehavior<,>)).As(typeof(IPipelineBehavior<,>));
        }
    }
}