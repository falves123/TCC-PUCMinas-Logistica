﻿using System.Diagnostics.CodeAnalysis;

using AutoMapper;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Events;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.EventHandlers.BundleEnrichmentedEvent;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations
{
    [ExcludeFromCodeCoverage]
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<ProcessNewSubscriberCommand, ProcessInstalledProductNewSubscriberCommand>();
            CreateMap<ProcessNewSubscriberCommand, ProcessFulfillmentOrderNewSubscriberCommand>();

            CreateMap<ProcessInstalledProductNewSubscriberCommand, BundleNewSubscriber>();
            CreateMap<ProcessFulfillmentOrderNewSubscriberCommand, BundleNewSubscriber>();

            CreateMap<BundleNewSubscriber, BundleEnrichmentedEvent>();
            CreateMap<Header, BundleEnrichmentedEvent.HeaderEvent>();
            CreateMap<CustomerParty, BundleEnrichmentedEvent.CustomerPartyEvent>();
            CreateMap<Product, BundleEnrichmentedEvent.ProductEvent>();
            CreateMap<Equipment, BundleEnrichmentedEvent.EquipmentEvent>();

            CreateMap<InstalledProduct, Product>();
            CreateMap<InstalledProduct, Equipment>();

            CreateMap<FulfillmentOrderItem, Product>();
            CreateMap<FulfillmentOrderItem, Equipment>();

            CreateMap<BundleEnrichmentedEvent, SendBundleToHistoryHandler.BundleEvent>();
            CreateMap<BundleEnrichmentedEvent.HeaderEvent, SendBundleToHistoryHandler.BundleEvent.HeaderEvent>();
            CreateMap<BundleEnrichmentedEvent.CustomerPartyEvent, SendBundleToHistoryHandler.BundleEvent.CustomerPartyEvent>();
            CreateMap<BundleEnrichmentedEvent.ProductEvent, SendBundleToHistoryHandler.BundleEvent.ProductEvent>();
            CreateMap<BundleEnrichmentedEvent.EquipmentEvent, SendBundleToHistoryHandler.BundleEvent.EquipmentEvent>();
        }
    }
}