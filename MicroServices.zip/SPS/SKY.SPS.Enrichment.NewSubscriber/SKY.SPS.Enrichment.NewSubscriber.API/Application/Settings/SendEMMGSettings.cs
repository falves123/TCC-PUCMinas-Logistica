﻿using SKY.SPS.CrossCutting.MessageBroker;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings
{
    public class SendEMMGSettings : MessageBrokerSettings
    {
        public short Priority { get; set; } = 99;
    }
}