﻿using SKY.SPS.CrossCutting.MessageBroker;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings
{
    public class EnrichmentSettings : MessageBrokerSettings
    {
    }
}