﻿using Oracle.ManagedDataAccess.Client;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.DataContexts
{
    public interface ISiebelDataContext
    {
        OracleConnection Connection { get; set; }
    }
}