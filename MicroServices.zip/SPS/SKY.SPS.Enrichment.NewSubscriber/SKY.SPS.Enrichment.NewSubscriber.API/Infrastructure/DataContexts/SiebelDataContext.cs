﻿using System;
using System.Data;

using Oracle.ManagedDataAccess.Client;

using Microsoft.Extensions.Configuration;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.DataContexts
{
    public class SiebelDataContext : ISiebelDataContext, IDisposable
    {
        public SiebelDataContext(IConfiguration config)
        {
            Connection = new OracleConnection(config.GetConnectionString(this.GetType().Name.Replace("DataContext", string.Empty)));
            Connection.Open();
        }

        public OracleConnection Connection { get; set; }

        public void Dispose()
        {
            if (Connection.State != ConnectionState.Closed)
                Connection.Close();
        }
    }
}