﻿using System.Linq;
using System.Threading.Tasks;

using Dapper;

using SKY.SPS.CrossCutting.Domain.Exceptions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;
using SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.DataContexts;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.Repositories
{
    public class FulfillmentOrderRepository : IFulfillmentOrderRepository
    {
        private readonly ISiebelDataContext _dataContext;

        public FulfillmentOrderRepository(ISiebelDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<FulfillmentOrder> QueryFulfillmentOrder(string number)
        {
            var query = @"SELECT sord.row_id AS Id
                               , conta.ou_num AS Account
                               , sord.order_num AS ""Number""
                               , sord.status_cd AS Status
                               , sord.created AS Created
                               , sord.x_order_type AS ""Type""
                               , sord.x_order_subtype AS SubType
	                           , sord.x_serv_channel AS SalesChannel
                               , sord.x_user_group AS UserGroup
                               , sord.x_login AS Username
			                FROM siebel.s_order sord
                               , siebel.s_org_ext conta
                           WHERE conta.row_id = sord.serv_accnt_id
                             AND sord.order_num = :order_num";

            var fulfillmentOrder = await _dataContext.Connection.QueryFirstOrDefaultAsync<FulfillmentOrder>(query, new { order_num = number }).ConfigureAwait(false);

            if(fulfillmentOrder is null)
                throw new BusinessRuleException("Pedido não localizado", "QueryFulfillmentOrder", number);

            query = @"SELECT sord_item.row_id AS ""RowId""
                           , sord_item.status_cd AS Status
                           , sord_item.x_comerc_status AS TradingStatus
                           , sord_item.action_cd AS ""Action""
                           , sord_item.port_num AS WorkOrderItem
                           , prod.name AS ""Name""
                           , prod.category_cd AS Category
                           , prod.sub_type_cd AS SubCategory
                           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'ExhibitionEnd') AS EndDate
				           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'No. SmartCard/SimCard') AS Smartcard
				           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'No. do IRD/Modem') AS SerialNumber
				           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'No. do ReceiverID') AS Rid
				           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'Modelo de IRD') AS Model
                           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'Tecnologia') AS Technology
				           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'Modify') AS ""Modify""
                           , (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'ID de Parâmetro ITV') AS Interactive
                           , NVL(prod.x_sky_ca_service_id, (SELECT xa.char_val FROM siebel.s_order_item_xa xa WHERE xa.order_item_id = sord_item.row_id AND xa.attr_name = 'SID')) AS Service
			            FROM siebel.s_order sord
                           , siebel.s_order_item sord_item
                           , siebel.s_prod_int prod
                       WHERE sord.row_id = sord_item.order_id(+)
                         AND sord_item.prod_id = prod.row_id(+)
                         AND sord.order_num = :order_num";

            fulfillmentOrder.AddAllItems((await _dataContext.Connection.QueryAsync<FulfillmentOrderItem>(query, new { order_num = number }).ConfigureAwait(false)).ToList());

            return fulfillmentOrder;
        }
    }
}