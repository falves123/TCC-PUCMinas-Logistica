﻿using System.Threading.Tasks;

using Dapper;

using SKY.SPS.CrossCutting.Domain.Exceptions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;
using SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.DataContexts;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.Repositories
{
    public class CustomerPartyRepository : ICustomerPartyRepository
    {
        private readonly ISiebelDataContext _dataContext;

        public CustomerPartyRepository(ISiebelDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<CustomerParty> QueryCustomerParty(string account)
        {
            var query = @"SELECT conta.ou_num AS Account
                               , (SELECT lov.name FROM siebel.s_addr_per per, siebel.s_lst_of_val lov WHERE conta.pr_addr_id = per.row_id and per.city = lov.low and per.state = lov.high and lov.type = 'GEOCODE' AND rownum <= 1) AS Zipcode
                               , (SELECT per.zipcode FROM siebel.s_addr_per per WHERE conta.pr_addr_id = per.row_id AND rownum <= 1) AS PostalCode
                               , (SELECT lov.name FROM siebel.s_lst_of_val lov WHERE lov.type = 'TIPO_CONTA' AND lov.val = conta.ou_type_cd AND rownum <= 1) AS Type
                               , ext.val_propstn AS DNA
                               , conta.x_dunn_level AS StepRule
                            FROM siebel.s_org_ext conta
                               , siebel.s_org_ext_t ext
                           WHERE conta.row_id = ext.par_row_id(+)
                             AND conta.ou_num = :account";

            var customerParty = await _dataContext.Connection.QueryFirstOrDefaultAsync<CustomerParty>(query, new { account }).ConfigureAwait(false);

            if (customerParty is null)
                throw new BusinessRuleException("Conta não localizada", "QueryCustomerParty", account);

            return customerParty;
        }
    }
}