﻿using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

using Dapper;

using SKY.SPS.CrossCutting.Domain.Exceptions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;
using SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.DataContexts;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.Repositories
{
    public class InstalledProductRepository : IInstalledProductRepository
    {
        private readonly ISiebelDataContext _dataContext;

        public InstalledProductRepository(ISiebelDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<IList<InstalledProduct>> QueryInstalledProductList(string account)
        {
            var query = @"SELECT name AS Name
                               , category_cd AS Category
                               , sub_type_cd AS SubCategory
                               , asset_num AS ""RowId""
                               , NVL(x_sky_ca_service_id, serviceId) AS Service
                               , rid AS Rid
                               , smartcard AS Smartcard
                               , DECODE(technology, 'SKY+', 'SD', technology) AS Technology
                               , interactive AS Interactive
                               , endDate AS EndDate
                               , last_upd AS UpdateDate
                               , serialNumber AS SerialNumber
                               , modelo AS Model
                               , status_cd AS Status
                               , x_comerc_status AS TradingStatus
                            FROM (SELECT produto.name
                                       , produto.category_cd
                                       , produto.sub_type_cd
                                       , parque.asset_num
                                       , parque.last_upd
                                       , produto.x_sky_ca_service_id
                                       , parque.status_cd
                                       , parque.x_comerc_status
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'No. do ReceiverID') rid
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'No. SmartCard/SimCard') smartcard
                                       , NVL((SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'Tecnologia'), (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'Família')) technology
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'ID de Parâmetro ITV') interactive
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'ExhibitionEnd') AS endDate
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'SID') AS serviceId
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'No. do IRD/Modem') AS serialNumber
                                       , (SELECT xa.char_val FROM siebel.s_asset_xa xa WHERE xa.asset_id = parque.row_id AND xa.attr_name = 'Modelo de IRD') AS modelo
                                    FROM siebel.s_asset parque
                                       , siebel.s_prod_int produto  
                                       , siebel.s_org_ext conta
                                   WHERE parque.bill_accnt_id = conta.row_id
                                     AND produto.row_id = parque.prod_id	 
                                     AND parque.status_cd = 'Active'
                                     AND conta.ou_num = :account)";

            var installedProducts = (await _dataContext.Connection.QueryAsync<InstalledProduct>(query, new { account }).ConfigureAwait(false)).ToList();

            if (installedProducts.Count.Equals(0))
                throw new BusinessRuleException("Produtos/Equipamentos não localizado", "QueryInstalledProductList", account);

            return installedProducts;
        }
    }
}