﻿using System.Linq;
using System.Collections.Generic;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.Extensions
{
    public static class InstalledProductExtension
    {
        public static IList<InstalledProduct> GetAllItemsWithService(this IList<InstalledProduct> products)
        {
            return products.ToList().FindAll(item => !string.IsNullOrEmpty(item.Service));
        }

        public static IList<InstalledProduct> GetEquipments(this IList<InstalledProduct> products)
        {
            return products.ToList().FindAll(item => "Equipamento".Equals(item.Category)
                        && "PayTV".Equals(item.SubCategory)
                        && !string.IsNullOrEmpty(item.Smartcard)
                        && item.Smartcard.Length.Equals(12));
        }
    }
}