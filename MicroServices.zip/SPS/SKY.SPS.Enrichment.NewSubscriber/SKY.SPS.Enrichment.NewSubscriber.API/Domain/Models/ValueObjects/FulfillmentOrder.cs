﻿using System.Linq;
using System.Collections.Generic;

using SKY.SPS.CrossCutting.Domain.Models;
using System;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class FulfillmentOrder : Entity
    {
        private readonly List<FulfillmentOrderItem> _items = new List<FulfillmentOrderItem>();

        public new string Id { get; init; } = string.Empty;

        public new DateTime Created { get; init; }

        public string Number { get; init; } = string.Empty;

        public string Status { get; init; } = string.Empty;

        public IReadOnlyCollection<FulfillmentOrderItem> Items => _items;

        public string Type { get; init; } = string.Empty;

        public string SubType { get; init; } = string.Empty;

        public string SalesChannel { get; init; } = string.Empty;

        public string UserGroup { get; init; } = string.Empty;

        public string Username { get; init; } = string.Empty;

        public string Account { get; init; } = string.Empty;

        public string Source => GetType().Name;

        public void AddItem(FulfillmentOrderItem item)
        {
            if(!_items.Contains(item))
                _items.Add(item);
        }

        public void AddAllItems(IList<FulfillmentOrderItem> items)
        {
            foreach (var item in items)
            {
                AddItem(item);
            }
        }

        public IList<FulfillmentOrderItem> GetAllItemsWithService()
        {
            return Items.ToList().FindAll(item => !string.IsNullOrEmpty(item.Service));
        }

        public IList<FulfillmentOrderItem> GetEquipments()
        {
            return Items.ToList().FindAll(item => "Equipamento".Equals(item.Category) 
                                                  && "PayTV".Equals(item.SubCategory) 
                                                  && !string.IsNullOrEmpty(item.Smartcard) 
                                                  && item.Smartcard.Length.Equals(12));
        }

        public override string ToString()
        {
            return Number;
        }
    }
}