﻿
namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class Header
    {
        public string Bundle { get; init; } = string.Empty;

        public string SourceSystem { get; init; } = string.Empty;

        public string User { get; init; } = string.Empty;

        public string Process { get; init; } = string.Empty;

        public override string ToString()
        {
            return $"{ Bundle } : { SourceSystem } : { User } : { Process }";
        }
    }
}