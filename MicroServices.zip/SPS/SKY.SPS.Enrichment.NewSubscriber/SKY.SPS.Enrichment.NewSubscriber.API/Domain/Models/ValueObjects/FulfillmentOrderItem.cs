﻿using System;

using SKY.SPS.CrossCutting.Domain.Models;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class FulfillmentOrderItem : Entity
    {
        public string RowId { get; init; } = string.Empty;

        public string Status { get; init; } = string.Empty;

        public string TradingStatus { get; init; } = string.Empty;

        public string Action { get; init; } = string.Empty;

        public string Modify { get; init; } = string.Empty;

        public string Category { get; init; } = string.Empty;

        public string SubCategory { get; init; } = string.Empty;

        public string Name { get; init; } = string.Empty;

        public DateTime EndDate { get; init; }

        public string Smartcard { get; init; } = string.Empty;

        public string SerialNumber { get; init; } = string.Empty;

        public string Rid { get; init; } = string.Empty;

        public string Model { get; init; } = string.Empty;

        public string Technology { get; init; } = string.Empty;

        public string WorkOrderItem { get; init; } = string.Empty;

        public string Service { get; init; } = string.Empty;

        public string Interactive { get; init; } = string.Empty;

        public string Source => GetType().Name;

        public override string ToString()
        {
            return Id;
        }
    }
}