﻿using System;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class InstalledProduct
    {
        public string RowId { get; init; } = string.Empty;

        public string Smartcard { get; init; } = string.Empty;

        public string Name { get; init; } = string.Empty;

        public string Category { get; init; } = string.Empty;

        public string SubCategory { get; init; } = string.Empty;

        public string Service { get; init; } = string.Empty;

        public string Rid { get; init; } = string.Empty;

        public string SerialNumber { get; init; } = string.Empty;

        public string Technology { get; init; } = string.Empty;

        public string Interactive { get; init; } = string.Empty;

        public DateTime EndDate { get; init; }

        public DateTime UpdateDate { get; init; }

        public string Status { get; init; } = string.Empty;

        public string TradingStatus { get; init; } = string.Empty;

        public string Model { get; init; } = string.Empty;

        public string ReturnFl { get; init; } = string.Empty;

        public string Source => GetType().Name;

        public override string ToString()
        {
            return Name;
        }
    }
}