﻿using System.Linq;
using System.Collections.Generic;

using SKY.SPS.CrossCutting.T020;
using SKY.SPS.CrossCutting.Utility;
using SKY.SPS.CrossCutting.Domain.Models;
using SKY.SPS.CrossCutting.T020.ValueObjects;
using SKY.SPS.CrossCutting.Domain.Exceptions;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class Equipment : ValueObject
    {
        private readonly List<Command> _commands = new List<Command>();
        private readonly List<Service> _services = new List<Service>();
        private readonly List<PersonalRegionBit> _personalRegionBits = new List<PersonalRegionBit>();

        public IReadOnlyCollection<Service> Services => _services;

        public IReadOnlyCollection<Command> Commands => _commands;

        public IReadOnlyCollection<PersonalRegionBit> PersonalRegionBits => _personalRegionBits;

        public string RowId { get; private set; } = string.Empty;

        public string Name { get; private set; } = string.Empty;

        public string Smartcard { get; private set; } = string.Empty;

        public string Category { get; private set; } = string.Empty;

        public string SubCategory { get; private set; } = string.Empty;

        public string Rid { get; private set; } = string.Empty;

        public string SerialNumber { get; private set; } = string.Empty;

        public string Bouquet { get; private set; } = string.Empty;

        public string Technology { get; private set; } = string.Empty;

        public decimal Amount { get; private set; }

        public string Model { get; private set; } = string.Empty;

        public string StatusBBVOD { get; private set; } = string.Empty;

        public string Status { get; private set; } = string.Empty;

        public string TradingStatus { get; private set; } = string.Empty;

        public string WorkOrderItem { get; private set; } = string.Empty;

        public string Source { get; private set; } = string.Empty;

        public void AddPersonalRegionBit(string bits)
        {
            if(bits.Length % 7 != 0)
                throw new BusinessRuleException("Lista de bits inválido", "Classification.Description", bits);

            foreach (var item in bits.Split('-'))
            {
                if(string.IsNullOrEmpty(item))
                    continue;

                var personalRegionBit = $"-{item}";

                if (!_personalRegionBits.ToList().Exists(x => x.Bit.Equals(personalRegionBit)))
                    _personalRegionBits.Add(new PersonalRegionBit(personalRegionBit));
            }
        }

        public void AddService(Product product)
        {
            if (product.Service.Length % 4 != 0)
                throw new BusinessRuleException("Lista de serviços inválido", "Product.Service", product.Service);

            foreach (var item in product.Service.SplitEvery(4))
            {
                if (_services.FirstOrDefault(x => x.Id.Equals(item)) == null)
                    _services.Add(new Service(item, ServiceAction.Add, product.EndDate.ToString("yyyyMMddHHmm")));
            }
        }

        public void AddCommand(Command command)
        {
            _commands.Add(command);
        }

        public void UpdateBouquet(string bouquet)
        {
            Bouquet = bouquet;
        }

        public void UpdateRid(string rid)
        {
            if (!string.IsNullOrEmpty(rid) && (string.IsNullOrEmpty(Rid)))
                Rid = rid;
        }

        public void UpdateAmount(decimal amount)
        {
            Amount = amount;
        }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return RowId;
        }
        public override string ToString()
        {
            return $"{ Name }";
        }
    }
}