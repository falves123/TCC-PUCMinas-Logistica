﻿
namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class CustomerParty
    {
        private string _type = string.Empty;

        public string Account { get; init; } = string.Empty;

        public string Zipcode { get; init; } = string.Empty;

        public string PostalCode { get; init; } = string.Empty;

        public string Type { get => _type; init => _type = value; }

        public string DNA { get; init; } = string.Empty;

        public string StepRule { get; init; } = string.Empty;

        public void ChangeAccountType(string type)
        {
            _type = type;
        }

        public override string ToString()
        {
            return Account;
        }
    }
}