﻿using System;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects
{
    public class Product
    {
        public string RowId { get; private set; } = string.Empty;

        public string Category { get; private set; } = string.Empty;

        public string SubCategory { get; private set; } = string.Empty;

        public string Name { get; private set; } = string.Empty;

        public string Service { get; private set; } = string.Empty;

        public DateTime EndDate { get; private set; }

        public string Status { get; private set; } = string.Empty;

        public string TradingStatus { get; private set; } = string.Empty;

        public string Interactive { get; private set; } = string.Empty;

        public string Source { get; private set; } = string.Empty;

        public override string ToString()
        {
            return $"{ Name }";
        }
    }
}