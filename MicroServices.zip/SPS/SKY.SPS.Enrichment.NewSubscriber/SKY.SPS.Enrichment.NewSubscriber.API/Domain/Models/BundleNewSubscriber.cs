﻿using System;
using System.Linq;
using System.Collections.Generic;

using SKY.SPS.CrossCutting.T020;
using SKY.SPS.CrossCutting.Domain.Models;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models
{
    public class BundleNewSubscriber : Entity, IAggregateRoot
    {
        private readonly List<Product> _products = new List<Product>();
        private readonly List<Equipment> _equipments = new List<Equipment>();

        public BundleNewSubscriber() { }

        public BundleNewSubscriber(string sourceSystem, string user, string process, string bundle, string correlationId)
        {
            Header = new Header {
                Bundle = bundle, 
                SourceSystem = sourceSystem, 
                User = user, 
                Process = process
            };

            CorrelationId = correlationId;
        }

        public string FulfillmentOrder { get; private set; } = string.Empty;

        public Header Header { get; } = new Header();

        public CustomerParty CustomerParty { get; private set; } = new CustomerParty();

        public IReadOnlyCollection<Product> Products => _products;

        public IReadOnlyCollection<Equipment> Equipments => _equipments;

        public void SetCustomerParty(CustomerParty customerParty)
        {
            CustomerParty = customerParty;
        }

        public void SetProducts(IEnumerable<Product> products)
        {
            foreach (var item in products)
            {
                AddProduct(item);
            }
        }

        public void SetEquipments(IEnumerable<Equipment> equipments)
        {
            foreach (var item in equipments)
            {
                AddEquipment(item);
            }
        }

        public void SetFulfillmentOrder(string fulfillmentOrder)
        {
            FulfillmentOrder = fulfillmentOrder;
        }

        private void SetBouquet(Equipment equipment)
        {
            var productGlobo = Products.FirstOrDefault(item => "Canal".Equals(item.Category) && "Globo".Equals(item.SubCategory));

            if (new[] { "H", "J" }.Any(item => item.Equals(CustomerParty.Type)))
            {
                var recharger = Products.Any(item => "Recarga".Equals(item.Category));

                if (recharger)
                    CustomerParty.ChangeAccountType("Y");
            }

            equipment.UpdateBouquet($"{ CustomerParty.Type }/{ equipment.Technology }/{ productGlobo?.Name }");
        }

        private void SetRid(Equipment equipment)
        {
            if (string.IsNullOrEmpty(equipment.Rid))
                equipment.UpdateRid(CalculateRID(equipment.SerialNumber, equipment.Model));
        }

        private void AddProduct(Product product)
        {
            if (!_products.Contains(product))
                _products.Add(product);
        }

        private void AddEquipment(Equipment equipment)
        {
            if (_equipments.Contains(equipment))
                return;

            if ("CONNECTED".Equals(equipment.StatusBBVOD))
                equipment.UpdateAmount(80m);

            SetBouquet(equipment);
            SetRid(equipment);
            AddService(equipment);

            _equipments.Add(equipment);
        }

        private void AddService(Equipment equipment)
        {
            var products = _products.ToList().FindAll(item => !string.IsNullOrEmpty(item.Service));

            foreach (var product in products)
            {
                equipment.AddService(product);
            }
        }

        public void CreateCommands()
        {
            foreach (var equipment in Equipments)
            {
                equipment.AddCommand(new CreateSubscriber(equipment.Smartcard, CustomerParty.Zipcode));

                if(equipment.PersonalRegionBits.Any())
                    equipment.AddCommand(new SetPersonalRegionBits(equipment.PersonalRegionBits));

                equipment.AddCommand(new AuthorizeServiceOppv(equipment.Services));
                equipment.AddCommand(new CreateIppvTokenSeries(equipment.Amount));

                if (!string.IsNullOrEmpty(equipment.Rid))
                    equipment.AddCommand(new SetReceiverId(equipment.Rid));

                equipment.AddCommand(new ClearPassword());
                equipment.AddCommand(new ResendAllPackets());
            }
        }

        private string CalculateRID(string serialNumber, string model)
        {
            if (string.IsNullOrEmpty(serialNumber) || !serialNumber.Length.Equals(17) || string.IsNullOrEmpty(model))
                return string.Empty;

            if ("S12".Equals(model))
                return string.Empty;

            if (new[] { "S14", "SH01", "SHR01", "SH10", "SH20", "SH25", "SH26", "SHR26", "SHR44" }.Any(line => line.Equals(model)))
            {
                var codeIrd = Math.Abs(long.Parse(serialNumber.Substring(6, 10)) - 2000000000);

                var avChipNumber = $"{codeIrd:00000000000}";

                var digit = CreateAvChipCheckDigit(Convert.ToUInt32(codeIrd));

                return avChipNumber + digit;
            }

            return string.Empty;
        }

        private static int CreateAvChipCheckDigit(UInt32 rid)
        {
            short shI;
            short shOddSum = 0;
            short shEvenSum = 0;
            UInt32 uintNum = rid;

            for (shI = 1; shI < 12; shI++)
            {
                var shDigit = (short)(uintNum % 10);
                uintNum = Convert.ToUInt32(uintNum / 10L);

                if ((shI % 2) == 1)
                {
                    shDigit *= 2;
                    if (shDigit >= 10) shDigit -= 9;
                    shOddSum += shDigit;
                }
                else
                    shEvenSum += shDigit;
            }

            var bytCkdig = ((10 - ((shEvenSum + shOddSum) % 10)) % 10);

            return bytCkdig;
        }
    }
}