﻿
namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands
{
    public class ProcessFulfillmentOrderNewSubscriberCommand : ProcessNewSubscriberCommand
    {
        public string FulfillmentOrder { get; set; } = string.Empty;

        public string WorkOrderItem { get; set; } = string.Empty;
    }
}