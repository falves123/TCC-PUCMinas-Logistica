﻿using SKY.SPS.CrossCutting.Domain.Events;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands
{
    public class ProcessNewSubscriberCommand : Message
    {
        public string Account { get; set; } = string.Empty;
       
        public string SourceSystem { get; set; } = string.Empty;

        public string User { get; set; } = string.Empty;

        public string Process { get; set; } = string.Empty;

        public string Bundle { get; set; } = string.Empty;

        public string Smartcard { get; set; } = string.Empty;
    }
}