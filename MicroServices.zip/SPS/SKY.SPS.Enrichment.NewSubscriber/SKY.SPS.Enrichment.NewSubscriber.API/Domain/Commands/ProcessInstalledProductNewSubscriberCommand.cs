﻿namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands
{
    public class ProcessInstalledProductNewSubscriberCommand : ProcessNewSubscriberCommand
    {
    }
}