﻿using System.Text.Json;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands
{
    public static class NewSubscriberCommandFactoryMethod
    {
        public static ProcessNewSubscriberCommand CreateCommand(string message)
        {
            var command = JsonSerializer.Deserialize<ProcessFulfillmentOrderNewSubscriberCommand>(message);

            if (string.IsNullOrEmpty(command?.FulfillmentOrder))
                return JsonSerializer.Deserialize<ProcessInstalledProductNewSubscriberCommand>(message)!;
            
            return command;
        }
    }
}