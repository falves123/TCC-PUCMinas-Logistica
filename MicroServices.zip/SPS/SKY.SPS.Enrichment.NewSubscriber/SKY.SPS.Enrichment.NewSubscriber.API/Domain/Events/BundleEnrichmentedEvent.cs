﻿using System;
using System.Collections.Generic;

using SKY.SPS.CrossCutting.T020;
using SKY.SPS.CrossCutting.Domain.Events;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Events
{
    public class BundleEnrichmentedEvent : Event
    {
        public string FulfillmentOrder { get; set; } = string.Empty;

        public string WorkOrderItem { get; set; } = string.Empty;

        public HeaderEvent Header { get; set; } = new HeaderEvent();

        public CustomerPartyEvent CustomerParty { get; set; } = new CustomerPartyEvent();

        public IList<ProductEvent> Products { get; set; } = Array.Empty<ProductEvent>();

        public IList<EquipmentEvent> Equipments { get; set; } = Array.Empty<EquipmentEvent>();

        public class HeaderEvent
        {
            public string Bundle { get; set; } = string.Empty;

            public string SourceSystem { get; set; } = string.Empty;

            public string User { get; set; } = string.Empty;

            public string Process { get; set; } = string.Empty;
        }

        public class CustomerPartyEvent
        {
            public string Account { get; set; } = string.Empty;

            public string Zipcode { get; set; } = string.Empty;

            public string PostalCode { get; set; } = string.Empty;

            public string Type { get; set; } = string.Empty;

            public string DNA { get; set; } = string.Empty;

            public string StepRule { get; set; } = string.Empty;
        }

        public class ProductEvent
        {
            public string RowId { get; set; } = string.Empty;

            public string Category { get; set; } = string.Empty;

            public string SubCategory { get; set; } = string.Empty;

            public string Name { get; set; } = string.Empty;

            public string Service { get; set; } = string.Empty;

            public DateTime EndDate { get; set; }

            public string Status { get; set; } = string.Empty;

            public string TradingStatus { get; set; } = string.Empty;

            public string Interactive { get; set; } = string.Empty;

            public string Source { get; set; } = string.Empty;
        }

        public class EquipmentEvent
        {
            public string RowId { get; set; } = string.Empty;

            public string Name { get; set; } = string.Empty;

            public string Smartcard { get; set; } = string.Empty;

            public string Category { get; set; } = string.Empty;

            public string SubCategory { get; set; } = string.Empty;

            public string Rid { get; set; } = string.Empty;

            public string SerialNumber { get; set; } = string.Empty;

            public string Bouquet { get; set; } = string.Empty;

            public string Technology { get; set; } = string.Empty;

            public decimal Amount { get; set; }

            public string Model { get; set; } = string.Empty;

            public string StatusBBVOD { get; set; } = string.Empty;

            public string Status { get; set; } = string.Empty;

            public string TradingStatus { get; set; } = string.Empty;

            public string Source { get; set; } = string.Empty;

            public IList<Command> Commands { get; set; } = Array.Empty<Command>();
        }
    }
}