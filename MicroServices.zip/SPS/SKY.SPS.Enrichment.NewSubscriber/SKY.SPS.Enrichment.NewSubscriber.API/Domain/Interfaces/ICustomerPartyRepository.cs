﻿using System.Threading.Tasks;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces
{
    public interface ICustomerPartyRepository
    {
        Task<CustomerParty> QueryCustomerParty(string account);
    }
}