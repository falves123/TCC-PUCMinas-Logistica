﻿using System.Threading.Tasks;
using System.Collections.Generic;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces
{
    public interface IInstalledProductRepository
    {
        Task<IList<InstalledProduct>> QueryInstalledProductList(string account);
    }
}