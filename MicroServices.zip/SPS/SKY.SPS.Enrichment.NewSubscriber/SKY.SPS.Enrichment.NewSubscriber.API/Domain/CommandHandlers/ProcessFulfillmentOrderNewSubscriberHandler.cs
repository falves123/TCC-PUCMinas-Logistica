﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

using MediatR;
using AutoMapper;
using FluentValidation.Results;

using SKY.SPS.ApiClient.ClassificationEBS;
using SKY.SPS.CrossCutting.Domain.Commands;
using SKY.SPS.CrossCutting.Domain.Exceptions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Events;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.Extensions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.CommandHandlers
{
    public class ProcessFulfillmentOrderNewSubscriberHandler : IRequestHandler<ProcessFulfillmentOrderNewSubscriberCommand, ResponseCommand>
    {
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;

        private readonly ICustomerPartyRepository _customerPartyRepository;
        private readonly IFulfillmentOrderRepository _fulfillmentOrderRepository;
        private readonly IInstalledProductRepository _installedProductRepository;
        private readonly ICommunicationsClassificationEBSV1 _classificationService;

        public ProcessFulfillmentOrderNewSubscriberHandler(IMapper mapper, IMediator mediator, ICustomerPartyRepository customerPartyRepository, IFulfillmentOrderRepository fulfillmentOrderRepository, IInstalledProductRepository installedProductRepository, ICommunicationsClassificationEBSV1 classificationService)
        {
            _mapper = mapper;
            _mediator = mediator;

            _customerPartyRepository = customerPartyRepository;
            _fulfillmentOrderRepository = fulfillmentOrderRepository;
            _installedProductRepository = installedProductRepository;
            _classificationService = classificationService;
        }

        public async Task<ResponseCommand> Handle(ProcessFulfillmentOrderNewSubscriberCommand request, CancellationToken cancellationToken)
        {
            try
            { 
                var fulfillmentOrderService = await _fulfillmentOrderRepository.QueryFulfillmentOrder(request.FulfillmentOrder).ConfigureAwait(false);

                if (string.IsNullOrEmpty(request.Account))
                    request.Account = fulfillmentOrderService.Account;

                var customerPartyService = await _customerPartyRepository.QueryCustomerParty(request.Account).ConfigureAwait(false);
                var installedProductsService = await _installedProductRepository.QueryInstalledProductList(request.Account).ConfigureAwait(false);
                var services = fulfillmentOrderService.GetAllItemsWithService();

                var productsModel = 0.Equals(services.Count) ? _mapper.Map<List<Product>>(installedProductsService.GetAllItemsWithService()) : _mapper.Map<List<Product>>(services);
                var customerPartyModel = _mapper.Map<CustomerParty>(customerPartyService);

                var equips = string.IsNullOrEmpty(request.Smartcard) ? _mapper.Map<List<Equipment>>(installedProductsService.GetEquipments()) : _mapper.Map<List<Equipment>>(fulfillmentOrderService.GetEquipments());

                if (!string.IsNullOrEmpty(request.Smartcard))
                    equips = equips.FindAll(item => request.Smartcard.Equals(item.Smartcard));
                else if (!string.IsNullOrEmpty(request.WorkOrderItem))
                    equips = equips.FindAll(item => request.WorkOrderItem.Equals(item.WorkOrderItem));

                if (equips is null || !equips.Any())
                    return new ResponseCommand(new ValidationFailure("Equipments", "Equipamento não localizado"));

                var model = new BundleNewSubscriber(request.SourceSystem, request.User, request.Process, request.Bundle, request.CorrelationId);

                model.SetCustomerParty(customerPartyModel);
                model.SetProducts(productsModel);
                model.SetEquipments(equips);
                model.SetFulfillmentOrder(request.FulfillmentOrder);

                foreach (var equipment in model.Equipments)
                {
                    var classification = await _classificationService.QueryClassificationListAsync("BOUQUET", "ClassificationEBO/ClassificationSpecification/Custom/Parameter", equipment.Bouquet, cancellationToken).ConfigureAwait(false);

                    equipment.AddPersonalRegionBit(classification.FirstOrDefault()!.Description);
                }

                model.CreateCommands();

                var domainEvent = _mapper.Map<BundleEnrichmentedEvent>(model);

                await _mediator.Publish(domainEvent, cancellationToken).ConfigureAwait(false);

                return new ResponseCommand("Enriquecimento realizado com sucesso");
            }
            catch (BusinessRuleException ruleException)
            {
                return new ResponseCommand(new ValidationFailure(ruleException.Property, ruleException.Message, ruleException.AttemptedValue));
            }
        }
    }
}