﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

using MediatR;
using AutoMapper;
using FluentValidation.Results;

using SKY.SPS.ApiClient.ClassificationEBS;
using SKY.SPS.CrossCutting.Domain.Commands;
using SKY.SPS.CrossCutting.Domain.Exceptions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Events;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.Extensions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.CommandHandlers
{
    public class ProcessInstalledProductNewSubscriberHandler : IRequestHandler<ProcessInstalledProductNewSubscriberCommand, ResponseCommand>
    {
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;

        private readonly ICustomerPartyRepository _customerPartyRepository;
        private readonly IInstalledProductRepository _installedProductRepository;
        private readonly ICommunicationsClassificationEBSV1 _classificationService;

        public ProcessInstalledProductNewSubscriberHandler(IMapper mapper, IMediator mediator, ICustomerPartyRepository customerPartyRepository, IInstalledProductRepository installedProductRepository, ICommunicationsClassificationEBSV1 classificationService)
        {
            _mapper = mapper;
            _mediator = mediator;

            _customerPartyRepository = customerPartyRepository;
            _installedProductRepository = installedProductRepository;
            _classificationService = classificationService;
        }

        public async Task<ResponseCommand> Handle(ProcessInstalledProductNewSubscriberCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var customerPartyService = await _customerPartyRepository.QueryCustomerParty(request.Account);
                var installedProductsService = await _installedProductRepository.QueryInstalledProductList(request.Account);

                var customerPartyModel = _mapper.Map<CustomerParty>(customerPartyService);
                var productsModel = _mapper.Map<List<Product>>(installedProductsService.GetAllItemsWithService());
                var equipmentsModel = _mapper.Map<List<Equipment>>(installedProductsService.GetEquipments());

                if (!string.IsNullOrEmpty(request.Smartcard))
                    equipmentsModel = equipmentsModel.FindAll(item => request.Smartcard.Equals(item.Smartcard));

                if (equipmentsModel is null || !equipmentsModel.Any())
                    return new ResponseCommand(new ValidationFailure("Equipments", "Equipamento não localizado"));

                var model = new BundleNewSubscriber(request.SourceSystem, request.User, request.Process, request.Bundle, request.CorrelationId);

                model.SetCustomerParty(customerPartyModel);
                model.SetProducts(productsModel);
                model.SetEquipments(equipmentsModel);

                foreach (var equipment in model.Equipments)
                {
                    var classification = (await _classificationService.QueryClassificationListAsync("BOUQUET", "ClassificationEBO/ClassificationSpecification/Custom/Parameter", equipment.Bouquet, cancellationToken).ConfigureAwait(false)).FirstOrDefault();

                    equipment.AddPersonalRegionBit(classification!.Description);
                }

                model.CreateCommands();

                var domainEvent = _mapper.Map<BundleEnrichmentedEvent>(model);

                await _mediator.Publish(domainEvent, cancellationToken).ConfigureAwait(false);

                return new ResponseCommand("Enriquecimento realizado com sucesso");
            }
            catch (BusinessRuleException ruleException)
            {
                return new ResponseCommand(new ValidationFailure(ruleException.Property, ruleException.Message, ruleException.AttemptedValue));
            }
        }
    }
}