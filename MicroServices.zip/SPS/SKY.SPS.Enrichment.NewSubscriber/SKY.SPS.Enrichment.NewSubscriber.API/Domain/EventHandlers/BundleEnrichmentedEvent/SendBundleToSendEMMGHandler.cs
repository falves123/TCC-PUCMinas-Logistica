﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

using MediatR;
using Microsoft.Extensions.Options;

using SKY.SPS.CrossCutting.Domain.Events;
using SKY.SPS.CrossCutting.MessageBroker;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.EventHandlers.BundleEnrichmentedEvent
{
    public class SendBundleToSendEMMGHandler : INotificationHandler<Events.BundleEnrichmentedEvent>
    {
        private readonly IMessageBrokerRepository<IOptions<SendEMMGSettings>> _messageBroker;
        private readonly SendEMMGSettings _settings;

        public SendBundleToSendEMMGHandler(IMessageBrokerRepository<IOptions<SendEMMGSettings>> messageBroker, IOptions<SendEMMGSettings> options)
        {
            _messageBroker = messageBroker;
            _settings = options.Value;
        }

        public async Task Handle(Events.BundleEnrichmentedEvent notification, CancellationToken cancellationToken)
        {
            var bundle = new Bundle {
                Name = notification.Header.Bundle,
                SourceSystem = notification.Header.SourceSystem,
                User = notification.Header.User,
                Process = notification.Header.Process,
                Account = notification.CustomerParty.Account,
                FulfillmentOrder = notification.FulfillmentOrder,
                WorkOrderItem = notification.WorkOrderItem,
                CorrelationId = notification.CorrelationId
            };

            foreach (var equipment in notification.Equipments)
            {
                bundle.Equipments.Add(new Equipment { RowId = equipment.RowId, Smartcard = equipment.Smartcard, Commands = equipment.Commands.Select(item => new Command { Name = item.Name, Request = item.ToString() }).ToList() });
            }

            await _messageBroker.Publish(bundle, priority: _settings.Priority, cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        public class Bundle : Event
        {
            public string Name { get; set; } = string.Empty;

            public string SourceSystem { get; set; } = string.Empty;

            public string User { get; set; } = string.Empty;

            public string Process { get; set; } = string.Empty;

            public string Account { get; set; } = string.Empty;

            public string FulfillmentOrder { get; set; } = string.Empty;

            public string WorkOrderItem { get; set; } = string.Empty;

            public IList<Equipment> Equipments { get; set; } = new List<Equipment>();
        }

        public class Equipment
        {
            public string RowId { get; set; } = string.Empty;

            public string Smartcard { get; set; } = string.Empty;

            public IList<Command> Commands { get; set; } = Array.Empty<Command>();
        }

        public class Command
        {
            public string Name { get; set; } = string.Empty;

            public string Request { get; set; } = string.Empty;
        }
    }
}