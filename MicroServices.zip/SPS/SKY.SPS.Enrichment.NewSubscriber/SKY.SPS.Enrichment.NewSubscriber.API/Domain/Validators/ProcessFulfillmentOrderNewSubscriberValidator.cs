﻿using System.Text.RegularExpressions;

using FluentValidation;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;

namespace SKY.SPS.Enrichment.NewSubscriber.API.Domain.Validators
{
    public class ProcessFulfillmentOrderNewSubscriberValidator : AbstractValidator<ProcessFulfillmentOrderNewSubscriberCommand>
    {
        public ProcessFulfillmentOrderNewSubscriberValidator()
        {
            RuleFor(command => command.Process).NotEmpty().WithMessage("Campo obrigatório").MaximumLength(50).WithMessage("Máximo 50 caracteres");
            RuleFor(command => command.Bundle).NotEmpty().WithMessage("Campo obrigatório").MaximumLength(50).WithMessage("Máximo 50 caracteres");
            RuleFor(command => command.SourceSystem).NotEmpty().WithMessage("Campo obrigatório").MaximumLength(50).WithMessage("Máximo 50 caracteres");
            RuleFor(command => command.User).NotEmpty().WithMessage("Campo obrigatório").MaximumLength(30).WithMessage("Máximo 30 caracteres");

            RuleFor(command => command.FulfillmentOrder).NotEmpty().WithMessage("Campo obrigatório").MaximumLength(40).WithMessage("Máximo 40 caracteres");

            RuleFor(command => command.Account).MaximumLength(40).WithMessage("Máximo 40 caracteres");
            RuleFor(command => command.Account).Matches("^[0-9]*$", RegexOptions.IgnoreCase).When(command => !string.IsNullOrEmpty(command.Account)).WithMessage("Valor inválido");

            RuleFor(command => command.Smartcard).Length(12, 12).When(command => !string.IsNullOrEmpty(command.Smartcard)).WithMessage("Deve conter 12 caracteres");
            RuleFor(command => command.Smartcard).Matches("^00\\d{10}$", RegexOptions.IgnoreCase).When(command => !string.IsNullOrEmpty(command.Smartcard)).WithMessage("Valor inválido");
        }
    }
}