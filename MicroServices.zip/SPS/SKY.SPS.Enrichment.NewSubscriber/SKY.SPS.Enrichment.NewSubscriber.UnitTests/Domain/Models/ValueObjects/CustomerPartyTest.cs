﻿using Xunit;

using SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Models.ValueObjects
{
    public class CustomerPartyTest
    {
        [Fact]
        public void ChangeAccountType_When_NewType_ShouldReturn_Updated()
        {
            // Arrange
            var type = "H";
            var model = CustomerPartyMock.CreateInstance;

            // Act
            model.ChangeAccountType(type);

            // Assert
            Assert.Equal(type, model.Type);
        }

        [Fact]
        public void Classification_When_CreateModel_ShouldReturn_CustomerParty()
        {
            // Arrange
            CustomerParty model;

            // Act
            model = CustomerPartyMock.CreateInstance;

            // Assert
            Assert.NotNull(model.Account);
            Assert.NotNull(model.Zipcode);
            Assert.NotNull(model.Type);
            Assert.NotEqual(0, model.GetHashCode());
            Assert.Equal(model.Account, model.ToString());
        }
    }
}