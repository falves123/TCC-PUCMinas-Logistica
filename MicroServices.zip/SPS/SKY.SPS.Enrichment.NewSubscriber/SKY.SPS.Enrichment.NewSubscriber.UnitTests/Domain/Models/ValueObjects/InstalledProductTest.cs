﻿using System;

using Xunit;

using SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Models.ValueObjects
{
    public class InstalledProductTest
    {
        [Fact]
        public void InstalledProduct_When_CreateModel_ShouldReturn_InstalledProduct()
        {
            // Arrange
            InstalledProduct model;

            // Act
            model = InstalledProductMock.InstalledProductFake;

            // Assert
            Assert.NotNull(model.Smartcard);
            Assert.NotNull(model.Name);
            Assert.NotNull(model.Category);
            Assert.NotNull(model.SubCategory);
            Assert.NotNull(model.Service);
            Assert.NotNull(model.Rid);
            Assert.NotNull(model.SerialNumber);
            Assert.NotNull(model.Technology);
            Assert.NotNull(model.Interactive);
            Assert.NotEqual(DateTime.MinValue, model.EndDate);
            Assert.NotEqual(DateTime.MinValue, model.UpdateDate);
            Assert.NotNull(model.Status);
            Assert.NotNull(model.TradingStatus);
            Assert.NotNull(model.Model);
            Assert.NotNull(model.ReturnFl);
            Assert.NotEqual(0, model.GetHashCode());
            Assert.NotEqual(InstalledProductMock.InstalledProductFake, model);
            Assert.Equal(model.Name, model.ToString());
        }
    }
}