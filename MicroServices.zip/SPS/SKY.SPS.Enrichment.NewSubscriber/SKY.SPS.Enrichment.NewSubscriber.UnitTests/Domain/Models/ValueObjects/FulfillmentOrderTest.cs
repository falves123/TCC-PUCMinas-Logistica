﻿using System;
using System.Collections.Generic;

using Xunit;

using SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Models.ValueObjects
{
    public class FulfillmentOrderTest
    {
        [Fact]
        public void FulfillmentOrder_When_CreateModel_ShouldReturn_FulfillmentOrder()
        {
            // Arrange
            FulfillmentOrder model;

            // Act
            model = FulfillmentOrderMock.Create;

            // Assert
            Assert.NotNull(model.Id);
            Assert.NotNull(model.Account);
            Assert.NotNull(model.Number);
            Assert.NotNull(model.Status);
            Assert.NotEqual(DateTime.MinValue, model.Created);
            Assert.NotNull(model.Type);
            Assert.NotNull(model.SubType);
            Assert.NotNull(model.SalesChannel);
            Assert.NotNull(model.UserGroup);
            Assert.NotNull(model.Username);
            Assert.NotEqual(0, model.GetHashCode());
            Assert.NotEqual(FulfillmentOrderMock.Create, model);
            Assert.Equal(model.Number, model.ToString());
        }

        [Fact]
        public void AddItem_When_AddItem_ShouldReturn_FulfillmentOrderItem()
        {
            // Arrange
            var model = FulfillmentOrderMock.Create;

            // Act
            model.AddItem(FulfillmentOrderMock.CreateItem);

            // Assert
            foreach (var item in model.Items)
            {
                Assert.NotNull(item.Id);
                Assert.NotNull(item.Status);
                Assert.NotNull(item.TradingStatus);
                Assert.NotNull(item.Action);
                Assert.NotNull(item.WorkOrderItem);
                Assert.NotNull(item.Name);
                Assert.NotNull(item.Category);
                Assert.NotNull(item.SubCategory);
                Assert.NotEqual(DateTime.MinValue, item.EndDate);
                Assert.NotNull(item.Smartcard);
                Assert.NotNull(item.SerialNumber);
                Assert.NotNull(item.Rid);
                Assert.NotNull(item.Model);
                Assert.NotNull(item.Technology);
                Assert.NotNull(item.Modify);
                Assert.NotNull(item.Interactive);
                Assert.NotNull(item.Service);
                Assert.NotEqual(0, item.GetHashCode());
                Assert.NotEqual(FulfillmentOrderMock.CreateItem, item);
                Assert.Equal(item.Id, item.ToString());
            }
        }

        [Fact]
        public void AddAllItems_When_AddItems_ShouldReturn_FulfillmentOrderItems()
        {
            // Arrange
            var model = FulfillmentOrderMock.Create;

            // Act
            model.AddAllItems(new List<FulfillmentOrderItem>
            {
                FulfillmentOrderMock.CreateItem,
                FulfillmentOrderMock.CreateItem
            });

            // Assert
            Assert.NotEmpty(model.Items);
            Assert.Equal(2, model.Items.Count);
        }
    }
}