﻿using System.Linq;
using System.Collections.Generic;

using Xunit;
using AutoMapper;

using SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Models
{
    public class BundleNewSubscriberTest
    {
        private readonly IMapper _mapper;

        public BundleNewSubscriberTest()
        {
            _mapper = new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile()); }).CreateMapper();
        }

        [Theory]
        [InlineData("49710920", "BR206900", "57690000", "N", "01000001000000000000000000000000100000000000000000000000000000000000000001000000000000100011000111110000000000000000000000000000011110000100000000000000000000001111111111111000000000000000000000000000000000111111111111111000000011111010111110110010000000000000001111111110111011101110001111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111100011111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", "Serie de cobranca passo 2")]
        [InlineData("49710920", "BR206900", "57690000", "N", "", "")]
        public void SetCustomerParty_When_ValidParameters_ShouldBe_Successfully(string account, string zipcode, string postalCode, string type, string dna, string stepRule)
        {
            // Arrange
            var model = Builders.NewSubscriberFake;
            var customerParty = new CustomerParty { Account = account, Zipcode = zipcode, PostalCode = postalCode, Type = type, DNA = dna, StepRule = stepRule };

            // Act
            model.SetCustomerParty(customerParty);

            // Assert
            Assert.NotNull(model.CustomerParty);
            Assert.Equal(customerParty.Account, model.CustomerParty.Account);
            Assert.Equal(customerParty.Zipcode, model.CustomerParty.Zipcode);
            Assert.Equal(customerParty.Type, model.CustomerParty.Type);
        }

        [Theory]
        [MemberData(nameof(InstalledProductMock.GetInstalledProductsToProductsFake), MemberType = typeof(InstalledProductMock))]
        public void SetProducts_When_ValidParameters_ShouldBe_Successfully(List<InstalledProduct> products)
        {
            // Arrange
            var model = Builders.NewSubscriberFake;
            var productsModel = _mapper.Map<List<Product>>(products);

            // Act
            model.SetProducts(productsModel);

            // Assert
            Assert.NotNull(model);
            Assert.NotEmpty(model.Products);

            var lst = model.Products.ToList();
            for (var i = 0; i < model.Products.Count; i++)
            {
                Assert.Equal(products[i].RowId, lst[i].RowId);
                Assert.Equal(products[i].Name, lst[i].Name);
                Assert.Equal(products[i].Category, lst[i].Category);
                Assert.Equal(products[i].SubCategory, lst[i].SubCategory);
                Assert.Equal(products[i].Service, lst[i].Service);
                Assert.Equal(products[i].Interactive, lst[i].Interactive);
                Assert.Equal(products[i].EndDate, lst[i].EndDate);
                Assert.Equal(products[i].Status, lst[i].Status);
                Assert.Equal(products[i].TradingStatus, lst[i].TradingStatus);
                Assert.Equal(products[i].Name, lst[i].ToString());
            }
        }

        [Theory]
        [MemberData(nameof(InstalledProductMock.GetInstalledProductsToEquipmentsFake), MemberType = typeof(InstalledProductMock))]
        public void SetEquipments_When_ValidParameters_ShouldBe_Successfully(List<InstalledProduct> equipments)
        {
            // Arrange
            var model = Builders.NewSubscriberFake;
            var equipmentsModel = _mapper.Map<List<Equipment>>(equipments);

            // Act
            model.SetEquipments(equipmentsModel);

            // Assert
            Assert.NotNull(model);
            Assert.NotEmpty(model.Equipments);

            var lst = model.Equipments.ToList();
            for (var i = 0; i < model.Equipments.Count; i++)
            {
                Assert.Equal(equipments[i].RowId, lst[i].RowId);
                Assert.Equal(equipments[i].Smartcard, lst[i].Smartcard);
                Assert.Equal(equipments[i].Name, lst[i].Name);
                Assert.Equal(equipments[i].Category, lst[i].Category);
                Assert.Equal(equipments[i].SubCategory, lst[i].SubCategory);
                Assert.Equal(equipments[i].Technology, lst[i].Technology);
                Assert.Equal(equipments[i].Status, lst[i].Status);
                Assert.Equal(equipments[i].TradingStatus, lst[i].TradingStatus);
                Assert.Equal(equipments[i].Model, lst[i].Model);
                Assert.Equal(equipments[i].Name, lst[i].ToString());
                Assert.NotNull(lst[i].Bouquet);
            }
        }

        [Fact]
        public void SetBouquet_When_ValidParameters_ShouldBe_Successfully()
        {
            // Arrange
            var model = Builders.NewSubscriberFake;
            var equipments = InstalledProductMock.InstalledProductsEquipmentServiceModelFake.ToList();

            var equipmentsModel = _mapper.Map<List<Equipment>>(equipments);
            var customerPartyModel = CustomerPartyMock.CreateInstance;
            var productsModel = _mapper.Map<List<Product>>(InstalledProductMock.InstalledProductsWithRechargerModelFake);

            model.SetCustomerParty(customerPartyModel);
            model.SetProducts(productsModel);

            // Act
            model.SetEquipments(equipmentsModel);

            // Assert
            Assert.NotNull(model);
            Assert.NotEmpty(model.Equipments);

            var lst = model.Equipments.ToList();
            for (var i = 0; i < model.Equipments.Count; i++)
            {
                Assert.NotNull(lst[i].Bouquet);
                Assert.NotNull(lst[i].Services);
                Assert.True(lst[i].Services.Count > 0);
            }
        }

        [Theory]
        [MemberData(nameof(InstalledProductMock.GetInstalledProductsToEquipmentsFake), MemberType = typeof(InstalledProductMock))]
        public void CreateCommands_When_ValidParameters_ShouldBe_Successfully(List<InstalledProduct> equipments)
        {
            // Arrange
            var model = Builders.NewSubscriberFake;
            var equipmentsModel = _mapper.Map<List<Equipment>>(equipments);
            var customerPartyModel = CustomerPartyMock.CreateInstance;
            var productsModel = _mapper.Map<List<Product>>(InstalledProductMock.InstalledProductsToProductsServiceModelFake);

            model.SetCustomerParty(customerPartyModel);
            model.SetProducts(productsModel);
            model.SetEquipments(equipmentsModel);

            foreach (var equipment in model.Equipments)
            {
                equipment.AddPersonalRegionBit("-YnD082-YnD083-YnD084-YnD085-YnD086-YnD087-YnD088-YnD089-YnD08A-YnD08B-YnD08C-YnD08D-YnD08E-YnD08F-YnD090");
            }

            // Act
            model.CreateCommands();

            // Assert
            Assert.NotNull(model);
            Assert.NotEmpty(model.Equipments);

            foreach (var equipment in model.Equipments)
            {
                Assert.NotNull(equipment.Commands);
                Assert.True(equipment.Commands.Count > 0);
            }
        }
    }
}