﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Moq;
using Xunit;
using MediatR;
using AutoMapper;

using SKY.SPS.ApiClient.ClassificationEBS;
using SKY.SPS.CrossCutting.Domain.Exceptions;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.CommandHandlers;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.CommandHandlers
{
    public class ProcessFulfillmentOrderNewSubscriberHandlerTest
    {
        private readonly CancellationToken _token;
        private readonly ProcessFulfillmentOrderNewSubscriberHandler _commandHandler;

        private readonly Mock<ICustomerPartyRepository> _customerPartyRepositoryMock;
        private readonly Mock<IFulfillmentOrderRepository> _fulfillmentOrderRepositoryMock;
        private readonly Mock<IInstalledProductRepository> _installedProductRepositoryMock;
        private readonly Mock<ICommunicationsClassificationEBSV1> _classificationServiceMock;

        public ProcessFulfillmentOrderNewSubscriberHandlerTest()
        {
            var mediatorMock = new Mock<IMediator>();
            var mapper = new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile()); }).CreateMapper();

            _token = It.IsAny<CancellationToken>();

            _customerPartyRepositoryMock = new Mock<ICustomerPartyRepository>();
            _fulfillmentOrderRepositoryMock = new Mock<IFulfillmentOrderRepository>();
            _installedProductRepositoryMock = new Mock<IInstalledProductRepository>();
            _classificationServiceMock = new Mock<ICommunicationsClassificationEBSV1>();

            _commandHandler = new ProcessFulfillmentOrderNewSubscriberHandler(mapper, mediatorMock.Object, _customerPartyRepositoryMock.Object, _fulfillmentOrderRepositoryMock.Object, _installedProductRepositoryMock.Object, _classificationServiceMock.Object);
        }

        [Theory]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "SKY.SPS.Enrichment.NewSubscriber", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "SKY.SPS.Enrichment.NewSubscriber", "PTV_BUNDLE_NEW_SUBSCRIBER", "")]
        [InlineData("", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "SKY.SPS.Enrichment.NewSubscriber", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956")]
        [InlineData("", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "")]
        public async Task Handle_When_Valid_Command_ShouldReturn_ResponseCommand_Without_Error(string account, string fulfillmentOrder, string sourceSystem, string user, string process, string bundle, string smartcard)
        {
            // Arrange
            var command = new ProcessFulfillmentOrderNewSubscriberCommand { Account = account, FulfillmentOrder = fulfillmentOrder, SourceSystem = sourceSystem, User = user, Process = process, Bundle = bundle, Smartcard = smartcard };

            _fulfillmentOrderRepositoryMock.Setup(x => x.QueryFulfillmentOrder(It.IsAny<string>())).Returns(Task.FromResult(FulfillmentOrderMock.FulfillmentOrderServiceModelFake()));
            _customerPartyRepositoryMock.Setup(x => x.QueryCustomerParty(It.IsAny<string>())).Returns(Task.FromResult(CustomerPartyMock.CreateInstance));
            _installedProductRepositoryMock.Setup(x => x.QueryInstalledProductList(It.IsAny<string>())).Returns(Task.FromResult(InstalledProductMock.InstalledProductsServiceModelFake));
            _classificationServiceMock.Setup(x => x.QueryClassificationListAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(ClassificationMock.CreateList));

            // Act
            var response = await _commandHandler.Handle(command, _token).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.Errors);
        }

        [Fact]
        public async Task Handle_When_QueryFulfillmentOrder_Throw_BusinessRuleException_ShouldReturn_ResponseCommand_With_Error()
        {
            // Arrange
            var exception = new BusinessRuleException("Hello world", "FulfillmentOrder", "test");
            var command = Builders.FulfillmentOrderNewSubscriberCommandFake;

            _fulfillmentOrderRepositoryMock.Setup(x => x.QueryFulfillmentOrder(It.IsAny<string>())).Throws(exception);

            // Act
            var response = await _commandHandler.Handle(command, _token).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.NotEmpty(response.Errors);

            foreach (var item in response.Errors)
            {
                Assert.Equal(exception.Message, item.ErrorMessage);
                Assert.Equal(exception.Property, item.PropertyName);
                Assert.Equal(exception.AttemptedValue, item.AttemptedValue);
            }
        }

        [Fact]
        public async Task Handle_When_QueryCustomerParty_Throw_BusinessRuleException_ShouldReturn_ResponseCommand_With_Error()
        {
            // Arrange
            var exception = new BusinessRuleException("Hello world", "FulfillmentOrder", "test");
            var command = Builders.FulfillmentOrderNewSubscriberCommandFake;

            _fulfillmentOrderRepositoryMock.Setup(x => x.QueryFulfillmentOrder(It.IsAny<string>())).Returns(Task.FromResult(FulfillmentOrderMock.FulfillmentOrderServiceModelFake()));
            _customerPartyRepositoryMock.Setup(x => x.QueryCustomerParty(It.IsAny<string>())).Throws(exception);

            // Act
            var response = await _commandHandler.Handle(command, _token).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.NotEmpty(response.Errors);

            foreach (var item in response.Errors)
            {
                Assert.Equal(exception.Message, item.ErrorMessage);
                Assert.Equal(exception.Property, item.PropertyName);
                Assert.Equal(exception.AttemptedValue, item.AttemptedValue);
            }
        }

        [Fact]
        public async Task Handle_When_QueryInstalledProductList_Throw_BusinessRuleException_ShouldReturn_ResponseCommand_With_Error()
        {
            // Arrange
            var exception = new BusinessRuleException("Hello world", "FulfillmentOrder", "test");
            var command = Builders.FulfillmentOrderNewSubscriberCommandFake;

            _fulfillmentOrderRepositoryMock.Setup(x => x.QueryFulfillmentOrder(It.IsAny<string>())).Returns(Task.FromResult(FulfillmentOrderMock.FulfillmentOrderServiceModelFake()));
            _customerPartyRepositoryMock.Setup(x => x.QueryCustomerParty(It.IsAny<string>())).Returns(Task.FromResult(CustomerPartyMock.CreateInstance));
            _installedProductRepositoryMock.Setup(x => x.QueryInstalledProductList(It.IsAny<string>())).Throws(exception);

            // Act
            var response = await _commandHandler.Handle(command, _token).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.NotEmpty(response.Errors);

            foreach (var item in response.Errors)
            {
                Assert.Equal(exception.Message, item.ErrorMessage);
                Assert.Equal(exception.Property, item.PropertyName);
                Assert.Equal(exception.AttemptedValue, item.AttemptedValue);
            }
        }

        [Fact]
        public async Task Handle_WhenThrow_OtherException_ShouldThrow_Exception()
        {
            // Arrange
            var applicationException = new ApplicationException("Hello world");

            _fulfillmentOrderRepositoryMock.Setup(x => x.QueryFulfillmentOrder(It.IsAny<string>())).Throws(applicationException);

            // Act
            var exception = await Assert.ThrowsAsync<ApplicationException>(() => _commandHandler.Handle(Builders.FulfillmentOrderNewSubscriberCommandFake, _token)).ConfigureAwait(false);

            // Assert
            Assert.NotNull(exception);
            Assert.Equal(applicationException.Message, exception.Message);
        }
    }
}