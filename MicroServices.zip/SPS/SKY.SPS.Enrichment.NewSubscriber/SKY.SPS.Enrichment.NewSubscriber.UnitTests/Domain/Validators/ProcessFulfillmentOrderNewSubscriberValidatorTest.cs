﻿using Xunit;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Validators;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Validators
{
    public class ProcessFulfillmentOrderNewSubscriberValidatorTest
    {
        private readonly ProcessFulfillmentOrderNewSubscriberValidator _validator;

        public ProcessFulfillmentOrderNewSubscriberValidatorTest()
        {
            _validator = new ProcessFulfillmentOrderNewSubscriberValidator();
        }

        [Theory]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "")]
        [InlineData("", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "")]
        public void Validate_When_ValidParameters_ShouldReturn_ValidationResult_Valid(string account, string fulfillmentOrder, string sourceSystem, string user, string process, string bundle, string smartcard)
        {
            // Arrange
            var command = new ProcessFulfillmentOrderNewSubscriberCommand { Account = account, FulfillmentOrder = fulfillmentOrder, SourceSystem = sourceSystem, User = user, Process = process, Bundle = bundle, Smartcard = smartcard };

            // Act
            var response = _validator.Validate(command);

            // Assert
            Assert.NotNull(response);
            Assert.True(response.IsValid);
            Assert.Empty(response.Errors);
        }

        [Theory]
        [InlineData("kjlsdjflksajflkdsjlfkjsaldjfl", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "Account")]
        [InlineData("5098437598730958467325780365036758947398573289475389", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "Account")]

        [InlineData("49710920", null, "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "FulfillmentOrder")]
        [InlineData("49710920", "", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "FulfillmentOrder")]
        [InlineData("49710920", "1-abcdefghijklmnopqrstuvxwyz01234567890abcdefghijklmn", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "FulfillmentOrder")]

        [InlineData("49710920", "1-69764088960", null, "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "SourceSystem")]
        [InlineData("49710920", "1-69764088960", "", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "SourceSystem")]
        [InlineData("49710920", "1-69764088960", "abcdefghijklmnopqrstuvxwyz01234567890abcdefghijklmn", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "SourceSystem")]

        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", null, "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "User")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "User")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "abcdefghijklmnopqrstuvxwyz01234567890abcdefghijklmn", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "User")]

        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", null, "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "Process")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "Process")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "abcdefghijklmnopqrstuvxwyz01234567890abcdefghijklmn", "PTV_BUNDLE_NEW_SUBSCRIBER", "000784282956", "Process")]

        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", null, "000784282956", "Bundle")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "", "000784282956", "Bundle")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "abcdefghijklmnopqrstuvxwyz01234567890abcdefghijklmn", "000784282956", "Bundle")]

        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "abc", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "abcdefghijkl", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "12345", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "00012345", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "00012345678999876", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "991234567899", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "123456789000", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "A00123456789", "Smartcard")]
        [InlineData("49710920", "1-69764088960", "SKY.SPS.Enrichment.NewSubscriber", "sps_user", "Enrichment", "PTV_BUNDLE_NEW_SUBSCRIBER", "00012345678A", "Smartcard")]
        public void Validate_When_InvalidParameters_ShouldReturn_ValidationResult_Invalid(string account, string fulfillmentOrder, string sourceSystem, string user, string process, string bundle, string smartcard, string propertyValidate)
        {
            // Arrange
            var command = new ProcessFulfillmentOrderNewSubscriberCommand { Account = account, FulfillmentOrder = fulfillmentOrder, SourceSystem = sourceSystem, User = user, Process = process, Bundle = bundle, Smartcard = smartcard };

            // Act
            var response = _validator.Validate(command);

            // Assert
            Assert.NotNull(response);
            Assert.False(response.IsValid);
            Assert.NotEmpty(response.Errors);

            foreach (var item in response.Errors)
            {
                Assert.Equal(propertyValidate, item.PropertyName);
            }
        }
    }
}