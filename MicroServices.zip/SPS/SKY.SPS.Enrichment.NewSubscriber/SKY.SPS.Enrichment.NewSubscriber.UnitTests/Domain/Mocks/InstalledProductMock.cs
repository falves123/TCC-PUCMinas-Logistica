﻿using System;
using System.Collections.Generic;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks
{
    public static class InstalledProductMock
    {
        public static readonly InstalledProduct InstalledProductToEquipment01 = CreateInstance(Guid.NewGuid().ToString(), "000807876016", "Equipamento", "Equipamento", "PayTV", "", "", "010A263412144340F", "HD", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "SHR26", "");
        public static readonly InstalledProduct InstalledProductToEquipment02 = CreateInstance(Guid.NewGuid().ToString(), "000582815346", "Equipamento", "Equipamento", "PayTV", "", "001357686946", "CE0A1421357686942", "SD", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "S14", "");
        public static readonly InstalledProduct InstalledProductToEquipment03 = CreateInstance(Guid.NewGuid().ToString(), "001137767347", "Equipamento", "Equipamento", "PayTV", "", "005446926130", "670A012544692613F", "HD", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "SH01", "");
        public static readonly InstalledProduct InstalledProductToEquipment04 = CreateInstance(Guid.NewGuid().ToString(), "000554329201", "Equipamento", "Equipamento", "PayTV", "", "", "010A540360243221D", "SD", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Em cancelamento", "DSR3421", "");
        public static readonly InstalledProduct InstalledProductToEquipment05 = CreateInstance(Guid.NewGuid().ToString(), "000807876016", "Equipamento", "Equipamento", "PayTV", "", "", "", "HD", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "SHR26", "");

        public static readonly InstalledProduct InstalledProductToProducts01 = CreateInstance(Guid.NewGuid().ToString(), "", "TV GLOBO SP", "Canal", "Globo", "021F", "", "", "", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToProducts02 = CreateInstance(Guid.NewGuid().ToString(), "", "COMBO SKY HDTV SLIM 2013 + CINEMA", "Pacotes", "Combo HD", "", "", "", "HD", "ITV 0", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToProducts03 = CreateInstance(Guid.NewGuid().ToString(), "", "Sky SIMPLIFICADO Bundle SKY MIX HD 2013 COMBO", "Bundle", "Canais", "0066009D039C01AA0391008F007700600080003F005D0076006F0075006E006B006A00740079008E00BE009B0212021100670078007E0082009F002E003E00A800170072007000A0005C00530084004F006C008A00890014001601C1", "", "", "", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToProducts04 = CreateInstance(Guid.NewGuid().ToString(), "", "Brasileirao Serie A", "Temporada", "Campeonato Nacional", "2FF9", "", "", "", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToProducts05 = CreateInstance(Guid.NewGuid().ToString(), "", "NEW MASTER II 2017 - A", "Pacotes", "Básico", "", "", "", "", "ITV 0", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToProducts06 = CreateInstance(Guid.NewGuid().ToString(), "", "BUNDLE SIMPLIFICADO MASTER 2017", "Bundle", "Canais", "00BE009E008000620089006B0066009D02270075007200740017022A0083006E01AB0076006F008E00770211006A00700098008A0212005D009B00820060006700790014000501AA01C1", "", "", "", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToProducts07 = CreateInstance(Guid.NewGuid().ToString(), "", "TV VANGUARDA - SÃO JOSÉ DOS CAMPOS", "Canal", "Globo", "021B", "", "", "", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");

        public static readonly InstalledProduct InstalledProductToRecharger01 = CreateInstance(Guid.NewGuid().ToString(), "", "SKY PRÉ PAGO FLEX C", "Livre", "Básico", "", "", "", "", "ITV F1", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToRecharger02 = CreateInstance(Guid.NewGuid().ToString(), "", "SKY BUNDLE FLEX", "Bundle", "Canais", "0206", "", "", "", "", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");
        public static readonly InstalledProduct InstalledProductToRecharger03 = CreateInstance(Guid.NewGuid().ToString(), "", "REC SMART - 30 DIAS", "Recarga", "Pacote Básico", "", "", "", "", "ITV R 0", DateTime.Now.AddDays(10), DateTime.Now.AddDays(-1), "Active", "Ativo", "", "");

        public static InstalledProduct InstalledProductFake =>
            new InstalledProduct
            {
                RowId = Guid.NewGuid().ToString(),
                Smartcard = "000807876016",
                Name = "Sky SIMPLIFICADO Bundle SKY MIX HD 2013 COMBO",
                Category = "Bundle",
                SubCategory = "Canais",
                Service = "0066009D039C01AA0391008F007700600080003F005D0076006F0075006E006B006A00740079008E00BE009B0212021100670078007E0082009F002E003E00A800170072007000A0005C00530084004F006C008A00890014001601C1",
                Rid = "014121443403",
                SerialNumber = "010A263412144340F",
                Technology = "HD",
                Interactive = "ITV 0",
                EndDate = DateTime.Now.AddDays(10),
                UpdateDate = DateTime.Now.AddDays(-1),
                Status = "Active",
                TradingStatus = "Ativo",
                Model = "SHR26",
                ReturnFl = "N"
            };

        public static InstalledProduct CreateInstance(string rowId, string smartcard, string name, string category, string subCategory, string service, string rid, string serialNumber, string technology, string interactive, DateTime endDate, DateTime updateDate, string status, string tradingStatus, string model, string returnFl)
        {
            return new InstalledProduct
            {
                RowId = rowId,
                Smartcard = smartcard,
                Name = name,
                Category = category,
                SubCategory = subCategory,
                Service = service,
                Rid = rid,
                SerialNumber = serialNumber,
                Technology = technology,
                Interactive = interactive,
                EndDate = endDate,
                UpdateDate = updateDate,
                Status = status,
                TradingStatus = tradingStatus,
                Model = model,
                ReturnFl = returnFl
            };
        }

        public static IList<InstalledProduct> InstalledProductsServiceModelFake =>
            new List<InstalledProduct>
            {
                InstalledProductMock.InstalledProductToProducts01,
                InstalledProductMock.InstalledProductToProducts02,
                InstalledProductMock.InstalledProductToProducts03,
                InstalledProductMock.InstalledProductToProducts04,
                InstalledProductMock.InstalledProductToProducts05,
                InstalledProductMock.InstalledProductToProducts06,
                InstalledProductMock.InstalledProductToEquipment01,
                InstalledProductMock.InstalledProductToEquipment02,
                InstalledProductMock.InstalledProductToEquipment03,
                InstalledProductMock.InstalledProductToEquipment04,
                InstalledProductMock.InstalledProductToEquipment05
            };

        public static IList<InstalledProduct> InstalledProductsEquipmentServiceModelFake =>
            new List<InstalledProduct>
            {
                InstalledProductMock.InstalledProductToEquipment01,
                InstalledProductMock.InstalledProductToEquipment02,
                InstalledProductMock.InstalledProductToEquipment03,
                InstalledProductMock.InstalledProductToEquipment04,
                InstalledProductMock.InstalledProductToEquipment05
            };

        public static IList<InstalledProduct> InstalledProductsToProductsServiceModelFake =>
            new List<InstalledProduct>
            {
                InstalledProductMock.InstalledProductToProducts01,
                InstalledProductMock.InstalledProductToProducts02,
                InstalledProductMock.InstalledProductToProducts03,
                InstalledProductMock.InstalledProductToProducts04,
                InstalledProductMock.InstalledProductToProducts05,
                InstalledProductMock.InstalledProductToProducts06,
                InstalledProductMock.InstalledProductToProducts07
            };

        public static IList<InstalledProduct> InstalledProductsWithRechargerModelFake =>
            new List<InstalledProduct>
            {
                InstalledProductMock.InstalledProductToRecharger01,
                InstalledProductMock.InstalledProductToRecharger02,
                InstalledProductMock.InstalledProductToRecharger03
            };

        public static IEnumerable<object[]> GetInstalledProductsToProductsFake()
        {
            yield return new object[] { new List<InstalledProduct> {
                InstalledProductMock.InstalledProductToProducts01,
                InstalledProductMock.InstalledProductToProducts02,
                InstalledProductMock.InstalledProductToProducts03
            }};

            yield return new object[] { new List<InstalledProduct> {
                InstalledProductMock.InstalledProductToProducts04,
                InstalledProductMock.InstalledProductToProducts05,
            }};

            yield return new object[] { new List<InstalledProduct> {
                InstalledProductMock.InstalledProductToProducts06,
                InstalledProductMock.InstalledProductToProducts07,
            }};
        }

        public static IEnumerable<object[]> GetInstalledProductsToEquipmentsFake()
        {
            yield return new object[] { new List<InstalledProduct> {
                InstalledProductMock.InstalledProductToEquipment01,
                InstalledProductMock.InstalledProductToEquipment02
            }};

            yield return new object[] { new List<InstalledProduct> {
                InstalledProductMock.InstalledProductToEquipment03,
                InstalledProductMock.InstalledProductToEquipment04
            }};

            yield return new object[] { new List<InstalledProduct> {
                InstalledProductMock.InstalledProductToEquipment05,
                InstalledProductMock.InstalledProductToEquipment01
            }};
        }
    }
}