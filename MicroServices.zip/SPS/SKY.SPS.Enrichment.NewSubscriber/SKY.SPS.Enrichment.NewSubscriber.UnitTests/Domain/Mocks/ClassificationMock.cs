﻿using System;
using System.Collections.Generic;

using SKY.SPS.ApiClient.ClassificationEBS;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks
{
    public static class ClassificationMock
    {
        public static IReadOnlyCollection<Classification> CreateList =>
            new List<Classification>
            {
                new Classification
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = "BOUQUET",
                    Description = "-YnA072-YnD074-YnD075-YnA076-YnD077-YnD078-YnD079-YnD07A-YnD07B-YnD07C-YnD07D-YnD07E-YnD07F-YnD080-YnD081-YnD082-YnD083-YnD084-YnD085-YnD086-YnD087-YnD088-YnD089-YnD08A-YnD08B-YnD08C-YnD08D-YnD08E-YnD08F-YnD090",
                    Active = true,
                    High = "APG Bit TV GLOBO SP",
                    Low = "RM22522",
                    LanguageIndependentCode = "BOUQUET_740",
                    Parameter = "N/HD/TV GLOBO SP"
                }
            };
    }
}