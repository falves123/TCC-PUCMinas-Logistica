﻿using System;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models.ValueObjects;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.Mocks
{
    public static class FulfillmentOrderMock
    {
        public static FulfillmentOrder Create =>
            new FulfillmentOrder
            {
                Id = Guid.NewGuid().ToString(),
                Account = "49710920",
                Number = "1-55238586783",
                Status = "Concluído",
                Created = DateTime.Now,
                Type = "Parque",
                SubType = "PPV",
                SalesChannel = "iCareSAC",
                UserGroup = "TN_Incid_ANL",
                Username = "acc00126"
            };

        public static FulfillmentOrderItem CreateItem =>
                new FulfillmentOrderItem
                {
                    RowId = Guid.NewGuid().ToString(),
                    Status = "Concluído",
                    TradingStatus = "Ativo",
                    Action = "Add",
                    WorkOrderItem = "175484891",
                    Name = "Equipamento",
                    Category = "Equipamento",
                    SubCategory = "PayTV",
                    EndDate = DateTime.Now.AddDays(5),
                    Smartcard = "001108082387",
                    SerialNumber = "CE0A2036220384375",
                    Rid = "016220384370",
                    Model = "SH20",
                    Technology = "HD",
                    Modify = "N",
                    Interactive = "ITV 0",
                    Service = "00BE0089022700750072007400690391006E00760062006F0211006A0098005D0067008A006600140005008F0080006B009D039C01AA008E007700700212009B00820060007E00840081009F"
                };

        public static FulfillmentOrder FulfillmentOrderServiceModelFake()
        {
            var order = new FulfillmentOrder
            {
                Account = "49710920",
                Number = "1-69764088960",
                Status = "Concluído",
                Type = "Cliente",
                SubType = "Reativação",
                SalesChannel = "",
                UserGroup = "ATEND_SAC_PA_MONITORA",
                Username = "alm12809"
            };

            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Update", "", "Equipamento - P", "Equipamento", "PayTV", DateTime.Now.AddDays(5), "000784282956", "CE0A2035400685131", "015400685135", "SH20", "HD", "M", "", ""));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Update", "", "Sky Modelo Zapper", "Modelo", "PayTV", DateTime.Now.AddDays(5), "", "", "", "", "", "", "", ""));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "Taxa de Locacao FAT - P", "Faturavel", "Locação", DateTime.Now.AddDays(5), "", "", "", "", "", "", "", ""));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Update", "", "Equipamento - P", "Equipamento", "PayTV", DateTime.Now.AddDays(5), "001153717184", "CE0AD123805618340", "003805618349", "SHR01", "HD", "M", "", ""));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "Sky Telecine HD - P", "A La Carte", "Filmes", DateTime.Now.AddDays(5), "", "", "", "", "HD", "", "", "00A2"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "Sky HBO MAX - P", "A La Carte", "Filmes", DateTime.Now.AddDays(5), "", "", "", "", "SD", "", "", "009600B8"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "Sky HBO MAX - P", "A La Carte", "Filmes", DateTime.Now.AddDays(5), "", "", "", "", "SD", "", "", "009600B8"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "Sky Telecine - P", "A La Carte", "Filmes", DateTime.Now.AddDays(5), "", "", "", "", "SD", "", "", "007F00B7"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "BUNDLE SIMPLIFICADO ADVANCED HD 2018 + FULL HD", "Bundle", "Canais", DateTime.Now.AddDays(5), "", "", "", "", "", "", "", "00BE0089022700750072007400690391006E00760062006F0211006A0098005D0067008A006600140005008F0080006B009D039C01AA008E007700700212009B00820060007E00840081009F"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "RPC TV - CURITIBA", "Canal", "Globo", DateTime.Now.AddDays(5), "", "", "", "", "", "", "", "0220"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "OPCIONAL FULL HD 2018", "Bundle", "Canais", DateTime.Now.AddDays(5), "", "", "", "", "HD", "", "", "00A101C10247039B00B6"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "Sky HBO HD - P", "A La Carte", "Filmes", DateTime.Now.AddDays(5), "", "", "", "", "HD", "", "", "00A3"));
            order.AddItem(CreateFulfillmentOrderItem(Guid.NewGuid().ToString(), "Concluído", "Ativo", "Add", "", "COMBO PLUS CINEMA HD 2018 - P", "Pacotes", "Combo HD Plus", DateTime.Now.AddDays(5), "", "", "", "", "HD", "", "ITV 0", ""));

            return order;
        }

        public static FulfillmentOrderItem CreateFulfillmentOrderItem(string rowId, string status, string tradingStatus, string action, string workOrderItem, string name, string category, string subCategory, DateTime endDate, string smartcard, string serialNumber, string rid, string model, string technology, string modify, string interactive, string service)
        {
            return new FulfillmentOrderItem
            {
                RowId = rowId,
                Status = status,
                TradingStatus = tradingStatus,
                Action = action,
                WorkOrderItem = workOrderItem,
                Name = name,
                Category = category,
                SubCategory = subCategory,
                EndDate = endDate,
                Smartcard = smartcard,
                SerialNumber = serialNumber,
                Rid = rid,
                Model = model,
                Technology = technology,
                Modify = modify,
                Interactive = interactive,
                Service = service
            };
        }
    }
}