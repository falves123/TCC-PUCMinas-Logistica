﻿using System.Threading;
using System.Threading.Tasks;

using Moq;
using Xunit;

using Microsoft.Extensions.Options;

using SKY.SPS.CrossCutting.MessageBroker;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.EventHandlers.BundleEnrichmentedEvent;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.EventHandlers
{
    public class SendBundleToSendEMMGHandlerTest
    {
        private readonly CancellationToken _token;
        private readonly SendBundleToSendEMMGHandler _commandHandler;
        private readonly Mock<IMessageBrokerRepository<IOptions<SendEMMGSettings>>> _messageBrokerMock;

        public SendBundleToSendEMMGHandlerTest()
        {
            _messageBrokerMock = new Mock<IMessageBrokerRepository<IOptions<SendEMMGSettings>>>();

            var options = Options.Create(new SendEMMGSettings());

            _token = new CancellationToken();

            _commandHandler = new SendBundleToSendEMMGHandler(_messageBrokerMock.Object, options);
        }

        [Fact]
        public async Task Handle_When_Event_Published_ShouldValidate_Bundle()
        {
            // Arrange
            SendBundleToSendEMMGHandler.Bundle response = null;

            _messageBrokerMock.Setup(x => x.Publish(It.IsAny<SendBundleToSendEMMGHandler.Bundle>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<short>(), CancellationToken.None))
                .Returns(Task.CompletedTask)
                .Callback<SendBundleToSendEMMGHandler.Bundle, string, string, short, CancellationToken>((a, b, c, d, e) => response = a);

            var expectedEvent = Builders.BundleEnrichmentedEventFake;

            // Act
            await _commandHandler.Handle(expectedEvent, _token).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Equal(expectedEvent.Header.SourceSystem, response.SourceSystem);
            Assert.Equal(expectedEvent.Header.User, response.User);
            Assert.Equal(expectedEvent.Header.Process, response.Process);
            Assert.Equal(expectedEvent.Header.Bundle, response.Name);
        }
    }
}