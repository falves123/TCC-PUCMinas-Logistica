﻿using System.Threading;
using System.Threading.Tasks;

using Moq;
using Xunit;
using AutoMapper;

using Microsoft.Extensions.Options;

using SKY.SPS.CrossCutting.MessageBroker;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.EventHandlers.BundleEnrichmentedEvent;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Domain.EventHandlers
{
    public class SendBundleToHistoryHandlerTest
    {
        private readonly CancellationToken _token;
        private readonly SendBundleToHistoryHandler _handler;
        private readonly Mock<IMessageBrokerRepository<IOptions<HistorySettings>>> _messageBrokerMock;

        public SendBundleToHistoryHandlerTest()
        {
            _messageBrokerMock = new Mock<IMessageBrokerRepository<IOptions<HistorySettings>>>();
            _token = new CancellationToken();

            var mapper = new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile()); }).CreateMapper();

            _handler = new SendBundleToHistoryHandler(mapper, _messageBrokerMock.Object);
        }

        [Fact]
        public async Task Handle_When_Event_Published_ShouldValidate_BundleEvent()
        {
            // Arrange
            SendBundleToHistoryHandler.BundleEvent response = null;
            _messageBrokerMock.Setup(x => x.Publish(It.IsAny<SendBundleToHistoryHandler.BundleEvent>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<short>(), CancellationToken.None))
                .Returns(Task.CompletedTask)
                .Callback<SendBundleToHistoryHandler.BundleEvent, string, string, short, CancellationToken>((a, b, c, d, e) => response = a);

            var expectedEvent = Builders.BundleEnrichmentedEventFake;

            // Act
            await _handler.Handle(expectedEvent, _token).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Equal(expectedEvent.Header.SourceSystem, response.Header.SourceSystem);
            Assert.Equal(expectedEvent.Header.User, response.Header.User);
            Assert.Equal(expectedEvent.Header.Process, response.Header.Process);
            Assert.Equal(expectedEvent.Header.Bundle, response.Header.Bundle);
        }
    }
}