﻿using System;

using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Models;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Events;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests
{
    public static class Builders
    {
        public static ProcessFulfillmentOrderNewSubscriberCommand FulfillmentOrderNewSubscriberCommandFake =>
            new ProcessFulfillmentOrderNewSubscriberCommand { 
                Account = "1511188114",
                FulfillmentOrder = "1-53242187074",
                SourceSystem = "SKY.SPS.Enrichment.NewSubscriber",
                User = "sps_user",
                Process = "Enrichment",
                Bundle = "PTV_BUNDLE_NEW_SUBSCRIBER",
                Smartcard = "000586014698"
            };

        public static ProcessInstalledProductNewSubscriberCommand InstalledProductNewSubscriberCommandFake =>
            new ProcessInstalledProductNewSubscriberCommand { 
                Account = "1511188114",
                SourceSystem = "SKY.SPS.Enrichment.NewSubscriber",
                User = "sps_user",
                Process = "Enrichment",
                Bundle = "PTV_BUNDLE_NEW_SUBSCRIBER",
                Smartcard = "000586014698"
            };

        public static BundleNewSubscriber NewSubscriberFake =>
            new BundleNewSubscriber(
                "SKY.SPS.Enrichment.NewSubscriber",
                "sps_user",
                "Enrichment",
                "PTV_BUNDLE_NEW_SUBSCRIBER",
                Guid.NewGuid().ToString()
            );

        public static BundleEnrichmentedEvent BundleEnrichmentedEventFake =>
            new BundleEnrichmentedEvent
            {
                CorrelationId = Guid.NewGuid().ToString(),
                CustomerParty = new BundleEnrichmentedEvent.CustomerPartyEvent
                {
                    Account = "1511188114",
                    DNA = "01000001000000000000000000000000100000000000000000000000000000000000000001000000000000100011000111110000000000000000000000000000011110000100000000000000000000001111111111111000000000000000000000000000000000111111111111111000000011111010111110110010000000000000001111111110111011101110001111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111100011111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111",
                    PostalCode = "57690000",
                    StepRule = "Serie de cobranca passo 2",
                    Type = "N",
                    Zipcode = "BR206900"
                }
            };
    }
}