﻿using System.Threading;
using System.Threading.Tasks;

using Moq;
using Xunit;
using MediatR;
using FluentValidation.Results;

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

using SKY.SPS.CrossCutting.Utility;
using SKY.SPS.CrossCutting.Enrichment;
using SKY.SPS.CrossCutting.Notification;
using SKY.SPS.CrossCutting.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Services;

namespace SKY.SPS.Enrichment.NewSubscriber.UnitTests.Application
{
    public class NewSubscriberServiceTest
    {
        private readonly Mock<IMediator> _mediatorMock;

        private readonly IEnrichmentService _service;
        private readonly CancellationToken _tokenMock;
        private readonly string _messageInstalledProductFake, _messageFulfillmentOrderFake;

        public NewSubscriberServiceTest()
        {
            _mediatorMock = new Mock<IMediator>();
            _tokenMock = It.IsAny<CancellationToken>();

            _messageInstalledProductFake = Builders.InstalledProductNewSubscriberCommandFake.ToSerialize();
            _messageFulfillmentOrderFake = Builders.FulfillmentOrderNewSubscriberCommandFake.ToSerialize();

            var settings = Options.Create(new ApplicationSettings());
            var loggerMock = new Mock<ILogger<NewSubscriberService>>();

            _service = new NewSubscriberService(_mediatorMock.Object, loggerMock.Object, settings);
        }

        [Fact]
        public async Task Process_When_Valid_ProcessInstalledProductNewSubscriberCommand_ShouldReturn_ResponseCommand_Without_Error()
        {
            // Arrange
            var responseCommand = new ResponseCommand();
            _mediatorMock.Setup(x => x.Send(It.IsAny<ProcessInstalledProductNewSubscriberCommand>(), _tokenMock)).Returns(Task.FromResult(responseCommand));

            // Act
            var response = await _service.Process(_messageInstalledProductFake, _tokenMock).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.Errors);

            _mediatorMock.Verify(x => x.Send(It.IsAny<ProcessInstalledProductNewSubscriberCommand>(), _tokenMock), Times.Once);
        }

        [Fact]
        public async Task Process_When_ValidationFailure_ProcessInstalledProductNewSubscriberCommand_ShouldReturn_ResponseCommand_With_Errors()
        {
            // Arrange
            var expected = new ValidationFailure("Process", "Campo obrigatório");
            var responseCommand = new ResponseCommand();
            responseCommand.AddError(expected);

            _mediatorMock.Setup(x => x.Send(It.IsAny<ProcessInstalledProductNewSubscriberCommand>(), _tokenMock)).Returns(Task.FromResult(responseCommand));

            // Act
            var response = await _service.Process(_messageInstalledProductFake, _tokenMock).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.NotEmpty(response.Errors);

            foreach (var failure in response.Errors)
            {
                Assert.Equal(expected.ErrorMessage, failure.ErrorMessage);
                Assert.Equal(expected.AttemptedValue, failure.AttemptedValue);
            }

            _mediatorMock.Verify(x => x.Publish(It.IsAny<NotificationCommand>(), _tokenMock), Times.Once);
        }

        [Fact]
        public async Task Process_When_Valid_ProcessFulfillmentOrderNewSubscriberCommand_ShouldReturn_ResponseCommand_Without_Error()
        {
            // Arrange
            var responseCommand = new ResponseCommand();
            _mediatorMock.Setup(x => x.Send(It.IsAny<ProcessFulfillmentOrderNewSubscriberCommand>(), _tokenMock)).Returns(Task.FromResult(responseCommand));

            // Act
            var response = await _service.Process(_messageFulfillmentOrderFake, _tokenMock).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.Errors);

            _mediatorMock.Verify(x => x.Send(It.IsAny<ProcessFulfillmentOrderNewSubscriberCommand>(), _tokenMock), Times.Once);
        }

        [Fact]
        public async Task Process_When_ValidationFailure_ProcessFulfillmentOrderNewSubscriberCommand_ShouldReturn_ResponseCommand_With_Errors()
        {
            // Arrange
            var expected = new ValidationFailure("Process", "Campo obrigatório");
            var responseCommand = new ResponseCommand();
            responseCommand.AddError(expected);

            _mediatorMock.Setup(x => x.Send(It.IsAny<ProcessFulfillmentOrderNewSubscriberCommand>(), _tokenMock)).Returns(Task.FromResult(responseCommand));

            // Act
            var response = await _service.Process(_messageFulfillmentOrderFake, _tokenMock).ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            Assert.NotEmpty(response.Errors);

            foreach (var failure in response.Errors)
            {
                Assert.Equal(expected.ErrorMessage, failure.ErrorMessage);
                Assert.Equal(expected.AttemptedValue, failure.AttemptedValue);
            }

            _mediatorMock.Verify(x => x.Publish(It.IsAny<NotificationCommand>(), _tokenMock), Times.Once);
        }
    }
}