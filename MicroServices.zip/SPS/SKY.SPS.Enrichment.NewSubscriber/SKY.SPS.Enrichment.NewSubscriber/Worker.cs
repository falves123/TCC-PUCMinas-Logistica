﻿using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;

using Microsoft.Extensions.Options;

using SKY.SPS.CrossCutting.Enrichment;
using SKY.SPS.CrossCutting.MessageBroker;
using SKY.SPS.CrossCutting.Domain.Commands;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings;

namespace SKY.SPS.Enrichment.NewSubscriber
{
    [ExcludeFromCodeCoverage]
    public class Worker : BackgroundTask
    {
        private readonly IEnrichmentService _service;

        public Worker(IOptions<EnrichmentSettings> settings, IEnrichmentService service) : base(settings)
        {
            _service = service;
        }

        protected override async Task<ResponseCommand> ProcessAsync(string message, CancellationToken cancellationToken)
        {
            return await _service.Process(message, cancellationToken).ConfigureAwait(false);
        }
    }
}