﻿using System.Diagnostics.CodeAnalysis;

using AutoMapper;
using StackExchange.Redis;

using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using SKY.SPS.CrossCutting.Caching;
using SKY.SPS.CrossCutting.Enrichment;
using SKY.SPS.CrossCutting.Notification;
using SKY.SPS.CrossCutting.MessageBroker;
using SKY.SPS.Enrichment.NewSubscriber.API.Domain.Interfaces;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Services;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Settings;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations;
using SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.DataContexts;
using SKY.SPS.Enrichment.NewSubscriber.API.Infrastructure.Repositories;

namespace SKY.SPS.Enrichment.NewSubscriber
{
    [ExcludeFromCodeCoverage]
    public static class Setup
    {
        public static void AddRabbitMQ(this IServiceCollection services)
        {
            services.AddSingleton<IRabbitMQDataContext<IOptions<EnrichmentSettings>>, RabbitMQDataContext<IOptions<EnrichmentSettings>>>();
            services.AddSingleton<IRabbitMQDataContext<IOptions<SendEMMGSettings>>, RabbitMQDataContext<IOptions<SendEMMGSettings>>>();
            services.AddSingleton<IRabbitMQDataContext<IOptions<HistorySettings>>, RabbitMQDataContext<IOptions<HistorySettings>>>();
            services.AddSingleton<IRabbitMQDataContext<IOptions<NotificationSettings>>, RabbitMQDataContext<IOptions<NotificationSettings>>>();
        }

        public static void AddRedisCache(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IConnectionMultiplexer>(sp =>
            {
                var config = ConfigurationOptions.Parse(configuration.GetConnectionString("Redis"), true);
                config.ResolveDns = true;

                return ConnectionMultiplexer.Connect(config);
            });
        }

        public static void AddAutoMapper(this IServiceCollection services)
        {
            services.AddSingleton(new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile()); }).CreateMapper());
        }

        public static void RegisterServices(this IServiceCollection services)
        {
            services.AddSingleton<IEnrichmentService, NewSubscriberService>();

            services.AddSingleton<ICustomerPartyRepository, CustomerPartyRepository>();
            services.AddSingleton<IFulfillmentOrderRepository, FulfillmentOrderRepository>();
            services.AddSingleton<IInstalledProductRepository, InstalledProductRepository>();

            services.AddScoped<ISiebelDataContext, SiebelDataContext>();

            services.AddSingleton<ICacheManager, RedisCache>();

            services.AddSingleton<IMessageBrokerRepository<IOptions<EnrichmentSettings>>, RabbitMQRepository<IOptions<EnrichmentSettings>>>();
            services.AddSingleton<IMessageBrokerRepository<IOptions<SendEMMGSettings>>, RabbitMQRepository<IOptions<SendEMMGSettings>>>();
            services.AddSingleton<IMessageBrokerRepository<IOptions<HistorySettings>>, RabbitMQRepository<IOptions<HistorySettings>>>();
            services.AddSingleton<IMessageBrokerRepository<IOptions<NotificationSettings>>, RabbitMQRepository<IOptions<NotificationSettings>>>();
        }

        public static void ConfigureSettings(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<ApplicationSettings>(configuration.GetSection("Application"));
            services.Configure<EnrichmentSettings>(configuration.GetSection("RabbitMQ_Enrichment"));
            services.Configure<SendEMMGSettings>(configuration.GetSection("RabbitMQ_SendEMMG"));
            services.Configure<HistorySettings>(configuration.GetSection("RabbitMQ_History"));
            services.Configure<NotificationSettings>(configuration.GetSection("RabbitMQ_Notification"));
        }
    }
}