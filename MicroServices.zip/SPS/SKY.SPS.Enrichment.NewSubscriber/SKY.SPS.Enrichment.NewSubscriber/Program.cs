﻿using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;

using Autofac;
using Autofac.Extensions.DependencyInjection;

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using SKY.SPS.ApiClient.ClassificationEBS;
using SKY.SPS.Enrichment.NewSubscriber.API.Application.Configurations;

namespace SKY.SPS.Enrichment.NewSubscriber
{
    [ExcludeFromCodeCoverage]
    public static class Program
    {
        private static IServiceCollection _services;

        private static Task Main()
        {
            return CreateHost().Build().RunAsync();
        }

        public static IHostBuilder CreateHost()
        {
            return Host
                    .CreateDefaultBuilder()
                    .ConfigureAppConfiguration(builder => builder.AddJsonFile("appsettings.Secrets.json", true))
                    .ConfigureServices(ConfigureServices)
                    .UseServiceProviderFactory(new AutofacServiceProviderFactory())
                    .ConfigureContainer<ContainerBuilder>(ConfigureContainer)
                ;
        }

        private static void ConfigureServices(HostBuilderContext context, IServiceCollection services)
        {
            services.ConfigureSettings(context.Configuration);
            services.AddRabbitMQ();
            services.AddAutoMapper();
            services.AddRedisCache(context.Configuration);
            services.AddCommunicationsClassificationEBSV1(context.Configuration);

            services.AddHostedService<Worker>();

            services.RegisterServices();

            _services = services;
        }

        private static void ConfigureContainer(HostBuilderContext context, ContainerBuilder container)
        {
            container.Populate(_services);
            container.RegisterModule(new MediatorModule());
        }
    }
}